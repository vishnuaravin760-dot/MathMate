import assert from 'node:assert/strict';
import worker from '../server/worker.mjs';
const env={GEMINI_API_KEY:'test-only-key',APP_TOKEN:'test-token-123456789012345'};
const make=b=>new Request('https://test.invalid/solve',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+env.APP_TOKEN},body:JSON.stringify(b)});
let calls=0;
globalThis.fetch=async(url,opts)=>{calls++;const p=JSON.parse(opts.body);assert.equal(p.generationConfig.responseMimeType,'application/json');assert.ok(p.systemInstruction.parts[0].text.startsWith('You transcribe'));assert.ok(!p.contents[0].parts[1].text.includes('LaTeX'));return Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify({expression:'((5^0+5^0)^2)/4',uncertain:false,note:''})}]}}]});};
for(const extra of [{mode:'transcribe',question:'read photo'},{question:'Transcribe the maths question from the ATTACHED IMAGE only. old request with formatting'}]){
const res=await worker.fetch(make({...extra,image:{mimeType:'image/jpeg',data:'YWJj'}}),env);assert.equal(res.status,200);assert.equal(JSON.parse((await res.json()).answer).expression,'((5^0+5^0)^2)/4');}
assert.equal((await worker.fetch(make({mode:'transcribe',question:'read'}),env)).status,400);assert.equal(calls,2);
console.log('Photo mode, existing APK compatibility, JSON format and missing-photo guard passed (mocked API).');
