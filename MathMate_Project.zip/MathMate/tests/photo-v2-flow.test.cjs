const vm=require('vm'),fs=require('fs'),assert=require('assert/strict');
const els={};function el(id){return els[id]||(els[id]={id,hidden:false,value:'',textContent:'',disabled:false,handlers:{},after(){},before(){},append(){},removeAttribute(){},scrollIntoView(){},addEventListener(n,f){this.handlers[n]=f},set innerHTML(s){for(const m of s.matchAll(/id="([^"]+)"/g))el(m[1])},get innerHTML(){return ''}})}
let quick=0,ai=0,calls=[],timers=[];el('solveButton').onclick=()=>quick++;el('aiButton').onclick=()=>ai++;
const c={$:el,document:{createElement:()=>el('created'+Object.keys(els).length),head:{append(){}}},window:{setPhotoState(){},PhotoReader:{readMathPhoto:id=>calls.push(id)}},MathMate:require('../app/src/main/assets/engine.js'),scanning:false,aiWorking:false,controls(){},photoBusy(){},resetResult(){},setTimeout:f=>{timers.push(f);return timers.length},clearTimeout(){},tr:e=>e};vm.createContext(c);vm.runInContext(fs.readFileSync('app/src/main/assets/vision-read.js','utf8'),c);
c.window.setPhotoState(true);c.window.setMathPhotoPreview('data:image/jpeg;base64,YWJj');el('readMathPhoto').onclick();assert.equal(calls.length,1);assert.equal(el('readMathPhoto').disabled,true);el('readMathPhoto').onclick();assert.equal(calls.length,1);
c.window.receivePhotoReading('stale','999',false,'',null);assert.equal(el('question').value,'');
c.window.receivePhotoReading(calls[0],'((5^0+5^0)^2)/4',false,'',null);assert.equal(c.MathMate.solve(el('question').value).answer,'1');el('solveButton').onclick();assert.equal(quick,0);el('confirmMathReading').onclick();el('solveButton').onclick();assert.equal(quick,1);
el('question').value='2+2';el('question').handlers.input();el('aiButton').onclick();assert.equal(ai,0);
el('readMathPhoto').onclick();c.window.receivePhotoReading(calls[1],'',true,'Denominator unclear',null);assert.ok(el('photoFlowStatus').textContent.includes('unclear'));assert.equal(el('readMathPhoto').disabled,false);
el('readMathPhoto').onclick();c.window.receivePhotoReading(calls[2],'',true,'','Location rejected');assert.equal(el('photoFlowStatus').textContent,'Location rejected');
el('readMathPhoto').onclick();timers.at(-1)();assert.ok(el('photoFlowStatus').textContent.includes('timed out'));c.window.setPhotoState(false);el('aiButton').onclick();assert.equal(ai,1);
console.log('Photo flow: explicit send, stale reply, confirmation, uncertainty, error and timeout passed.');

// Offline photo reading uses the on-device draft without sending an AI request.
c.window.setPhotoState(true);c.window.setMathPhotoPreview('new-photo');
const beforeOffline=calls.length;
c.window.receiveOCR('7(x+10)=70',null);el('readOfflinePhoto').onclick();
assert.equal(el('question').value,'7(x+10)=70');assert.equal(calls.length,beforeOffline);
el('confirmMathReading').onclick();el('solveButton').onclick();assert.equal(c.MathMate.solve(el('question').value).answer,'x = 0');
c.window.setMathPhotoPreview('another-photo');el('readOfflinePhoto').onclick();assert.equal(el('question').value,'');
console.log('Offline draft: no AI request, reviewed expression, offline equation and stale-photo clearing passed.');
