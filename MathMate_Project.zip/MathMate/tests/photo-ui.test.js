'use strict';
// Test the packaged JavaScript event flow without a browser or Android device.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const page=fs.readFileSync(__dirname+'/../app/src/main/assets/index.html','utf8');
const elements=new Map();
function element(id){if(elements.has(id))return elements.get(id);const e={id,value:id==='formula'?'percentage':'',textContent:'',hidden:true,disabled:false,options:[],children:[],classList:{toggle(){},add(){},remove(){}},setAttribute(){},focus(){},setSelectionRange(a,b){this.selectionStart=a;this.selectionEnd=b},append(...items){this.children.push(...items)},replaceChildren(){this.children=[]},scrollIntoView(){},querySelectorAll(){return []}};elements.set(id,e);return e;}
const storage=new Map(),context={console,document:{documentElement:{},getElementById:element,querySelectorAll(){return []},createElement(tag){return element('generated-'+elements.size)}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)}};
context.window=context;vm.createContext(context);
for(const m of page.matchAll(/<script>([\s\S]*?)<\/script>/g))vm.runInContext(m[1],context);
let source=null;context.PhotoReader={openPhoto:s=>source=s};
element('cameraButton').onclick();assert.equal(source,'camera');assert.equal(element('cameraButton').disabled,true);
context.receiveOCR('2x + y = 10\nx − y = 20',null);
assert.equal(element('cameraButton').disabled,false);assert.equal(element('question').value,'2x + y = 10\nx - y = 20');assert.equal(element('result').hidden,true);
element('solveButton').onclick();assert.equal(element('answer').textContent,'x = 10, y = -10');
element('galleryButton').onclick();assert.equal(source,'gallery');context.receiveOCR(null,'Cancelled');assert.equal(element('error').hidden,true);assert.equal(element('solveButton').disabled,false);
element('galleryButton').onclick();context.receiveOCR(null,'No clear text found.');assert.equal(element('error').hidden,false);assert.equal(element('error').textContent,'No clear text found.');
const q='x² − 5x + 6 = 0';context.receiveOCR(q,null);assert.equal(element('question').value,'x^2 - 5x + 6 = 0');element('solveButton').onclick();assert.equal(element('answer').textContent,'x1 = 2, x2 = 3');
context.receiveOCR('<script>alert(1)</script>',null);assert.equal(element('question').value,'<script>alert(1)</script>');assert.equal(element('result').hidden,true);
delete context.PhotoReader;element('cameraButton').onclick();assert.equal(element('error').hidden,false);
// AI uses the native bridge: no token is exposed in HTML/JavaScript.
let aiCall=null;context.PhotoReader={solveAI:(...args)=>aiCall=args,configureAI:()=>{},clearPhoto:()=>context.setPhotoState(false)};
context.setPhotoState(true);assert.equal(element('includePhoto').checked,false);
element('question').value='12 / 3';element('aiButton').onclick();assert.equal(aiCall[0],'12 / 3');assert.equal(aiCall[2],false);assert.equal(element('aiButton').disabled,true);
context.receiveAI('12 ÷ 3 = 4',null,false);assert.equal(element('answer').textContent,'12 ÷ 3 = 4');assert.equal(element('aiButton').disabled,false);
element('includePhoto').checked=true;element('aiButton').onclick();assert.equal(aiCall[2],true);
context.receiveAI(null,'Incorrect app access code',false);assert.equal(element('error').textContent,'Incorrect app access code');assert.equal(element('aiButton').disabled,false);
element('removePhoto').onclick();assert.equal(element('photoChoice').hidden,true);assert.equal(element('includePhoto').checked,false);
console.log('Photo and AI UI logic passed.');
console.log('Photo UI logic passed: native bridge, cancel/error, manual review, normalization, solver handoff and unsupported-browser handling.');
