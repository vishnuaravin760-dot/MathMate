const assert=require('node:assert/strict'),S=require('../app/src/main/assets/study.js');
for(const q of S.bank){assert.ok(q.q.length===2&&q.hint.length===2&&q.why.length===2);assert.ok(S.correct(q.answer,q));assert.ok(!S.correct(q.answer+1,q));}
assert.equal(new Set(S.bank.map(q=>q.id)).size,S.bank.length);
assert.equal(S.convert(2.5,'length','m','cm').result,250);assert.equal(S.convert(1500,'mass','g','kg').result,1.5);assert.equal(S.convert(1.5,'time','h','min').result,90);assert.throws(()=>S.convert(-1,'length','m','cm'));assert.throws(()=>S.convert(1,'length','m','h'));assert.throws(()=>S.convert(Infinity,'time','s','h'));
for(const [group,units]of Object.entries(S.units))for(const from of Object.keys(units))for(const to of Object.keys(units))for(const value of [0,.25,1,12.5,99999]){const x=S.convert(value,group,from,to).result,y=S.convert(x,group,to,from).result;assert.ok(Math.abs(y-value)<1e-8);}
console.log('Study question data, units and round-trip conversions passed');
