const assert=require('node:assert/strict'),C=require('../app/src/main/assets/challenges.js'),M=require('../app/src/main/assets/engine.js');
assert.equal(C.bank.length,2600);assert.equal(Object.keys(C.topics).length,26);assert.equal(new Set(C.bank.map(q=>q.id)).size,2600);assert.equal(new Set(C.bank.map(q=>q.q[0])).size,2600);
const near=(a,b,tol=1e-8)=>assert.ok(Math.abs(a-b)<=tol*Math.max(1,Math.abs(b)),`${a} != ${b}`);
for(const q of C.bank){assert.equal(q.q.length,2);assert.ok(q.q.every(s=>typeof s==='string'&&s.length));assert.ok(q.hint.every(Boolean));assert.ok(q.steps.every(s=>s.length>=2));assert.ok(Number.isFinite(q.answer));assert.ok(!JSON.stringify(q).includes('undefined'));assert.ok(C.matches(q.answer,q));assert.ok(!C.matches(q.answer+1,q));const s=q.q[0],nums=[...s.matchAll(/\d+(?:\.\d+)?/g)].map(m=>Number(m[0]));let ref;
 switch(q.topic){
 case 'advancedbodmas':
 case 'bodmas':ref=Number(M.solve(s.split(': ')[1].replace(' = ?',''),false).answer);break;
 case 'add':ref=nums[0]+nums[1];break;case 'subtract':ref=nums[0]-nums[1];break;case 'multiply':ref=nums[0]*nums[1];break;case 'divide':ref=nums[0]/nums[1];break;
 case 'fractions':ref=nums[0]/nums[1]+nums[2]/nums[3];break;case 'decimals':ref=nums[0]+nums[1];break;case 'percent':ref=nums[0]*nums[1]/100;break;
 case 'x':{const expr=s.split(': ')[1].replace(/\.$/,'');const [left,right]=expr.split('=');near(M.calc(M.parse(left),{x:q.answer}),Number(right));ref=q.answer;break;}
 case 'simultaneous':{const m=s.match(/x \+ y = (\d+); x − y = (-?\d+)/);const sum=Number(m[1]),diff=Number(m[2]);const y=sum-q.answer;near(q.answer-y,diff);ref=(sum+diff)/2;break;}
 case 'quadratic':{const m=s.match(/x² − (\d+)x \+ (\d+)/),b=Number(m[1]),c=Number(m[2]);near(q.answer*q.answer-b*q.answer+c,0);ref=(b-Math.sqrt(b*b-4*c))/2;break;}
 case 'ap':ref=nums[0]+(nums[3]-1)*(nums[1]-nums[0]);break;
 case 'gp':ref=nums[2]*(nums[2]/nums[1])**2;break;
 case 'sequence':{const v=nums.slice(0,4);ref=(Math.sqrt(v[3])+1)**2;assert.equal(v[1]-v[0]+2,v[2]-v[1]);break;}
 case 'hidden':{const row=s.split('\n').at(-1).match(/\d+/g).map(Number);ref=row[0]*row[1]+row[2];break;}
 case 'factors':if(s.includes('PRIME')){const n=nums[0];ref=Array.from({length:n-1},(_,i)=>i+2).find(d=>n%d===0);}else{const [a,b]=nums;for(let d=1;d<=Math.min(a,b);d++)if(a%d===0&&b%d===0)ref=d;}break;
 case 'geometry':ref=s.includes('perimeter')?2*(nums[0]+nums[1]):nums[0]*nums[1];break;
 case 'pythagoras':ref=Math.hypot(nums[0],nums[1]);break;
 case 'trig':ref=nums[0]*Math.sin(nums[1]*Math.PI/180)+nums[2]*Math.cos(nums[3]*Math.PI/180);break;
 case 'derivative':{const a=nums[0],power=nums[1],h=1e-5;ref=(a*(1+h)**power-a*(1-h)**power)/(2*h);near(q.answer,ref,1e-6);ref=q.answer;break;}
 case 'integral':{const upper=nums[1],a=nums[2];let sum=0;for(let j=0;j<100;j++){const l=upper*j/100,r=upper*(j+1)/100;sum+=(a*l+a*r)/2*(r-l);}ref=sum;break;}
 case 'probability':ref=nums[0]/(nums[0]+nums[1]);break;
 case 'statistics':{const v=s.split(': ')[1].match(/\d+/g).map(Number);ref=s.includes('median')?v.sort((a,b)=>a-b)[2]:v.reduce((a,b)=>a+b,0)/v.length;break;}
 case 'units':ref=s.includes('metres')?nums[0]*100:nums[0]*60;break;
 case 'life':ref=nums[0]*(1-nums[1]/100);break;
 default:throw Error(q.topic);
 }near(q.answer,ref);const shown=M.solve(q.display,false);near(Number(shown.answer),q.answer);}
for(const topic of Object.keys(C.topics))assert.equal(C.bank.filter(q=>q.topic===topic).length,100);
console.log('2,600 distinct bilingual questions checked independently: arithmetic, equation substitution, roots, sequences, primes, geometry, finite-difference derivatives, numerical integrals, probability and units.');
