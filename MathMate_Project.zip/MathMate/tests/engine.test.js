'use strict';
const assert=require('node:assert/strict');
const M=require('../app/src/main/assets/engine.js');
let count=0;
function eq(q,values){const r=M.solve(q);assert.equal(r.values.length,values.length,q);values.forEach((v,i)=>assert.ok(Math.abs(r.values[i]-v)<=1e-9*Math.max(1,Math.abs(v)),`${q}: ${r.answer}`));count++;}
function error(q){assert.throws(()=>M.solve(q),q);count++;}
eq('(125+75)/4',[50]);eq('2+3*4',[14]);eq('2^3^2',[512]);eq('-2^2',[-4]);eq('(-2)^2',[4]);eq('2^-2',[.25]);eq('sqrt(144)+15%*200',[42]);eq('sin(30)',[.5]);eq('cos(60)',[.5]);eq('tan(45)',[1]);eq('log(1000)',[3]);eq('ln(e)',[1]);eq('2(3+4)',[14]);eq('2pi',[2*Math.PI]);eq('abs(-5)',[5]);
eq('2x+5=15',[5]);eq('2x+y=10\nx-y=20',[10,-10]);eq('x+y=5;x-y=1',[3,2]);eq('x/2+1=4',[6]);eq('x^2-5x+6=0',[2,3]);eq('(x-2)^2=0',[2]);eq('x^2=0',[0]);eq('x^2=4',[-2,2]);eq('x^2+1=0',[]);eq('0x=1',[]);eq('x=x',[]);eq('x+y=2;2x+2y=4',[]);eq('x+y=2;2x+2y=5',[]);eq('0=1;0=2',[]);eq('0=0;0=1',[]);
assert.equal(M.solve('0=1;0=2').answer,'No solution');assert.equal(M.solve('x+y=2;2x+2y=4').answer,'Infinitely many solutions');
for(const q of ['1/0','sqrt(-1)','tan(90)','x^3=2','1/x=2','x+y=1','y=3','x^2+y=1;x+y=2','2+','(2+3','hello','alert(1)','2x=','x==2','2\n3','2^10000'])error(q);
// Verify roots by substituting into independently generated equations.
for(let a=-7;a<=7;a++)for(let b=-5;b<=5;b++){
 const r=M.solve(`x^2 + ${-(a+b)}x + ${a*b} = 0`);
 const roots=a===b?[a]:[a,b].sort((x,y)=>x-y);assert.equal(r.values.length,roots.length);
 roots.forEach((v,i)=>assert.ok(Math.abs(r.values[i]-v)<1e-9));count++;
}
console.log(`${count} maths checks passed.`);
