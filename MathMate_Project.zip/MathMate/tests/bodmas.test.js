const M=require('../app/src/main/assets/engine.js'),assert=require('node:assert/strict');
for(const [expression,answer]of [['2+3*4',14],['(2+3)*4',20],['12/3*2',8],['24/4*3/2',9],['10-4+2',8],['10+4-2',12],['2^3*4+1',33],['6+(8-3)*2^2',26],['{6+[8-3]*2^2}',26],['sqrt(9+7)*2',8],['-2^2',-4],['(-2)^2',4],['2^3^2',512],['2^-2',.25],['[2+{3*(4+1)}]',17]])assert.equal(Number(M.solve(expression).answer),answer,expression);
for(const expression of ['[2+3)','{2+3]','(2+[3*4)','[2+3','{1/0}','[sqrt(-1)]'])assert.throws(()=>M.solve(expression),expression);
assert.equal(M.solve('2+3*4').steps[0],'3 * 4 = 12');assert.equal(M.solve('12/3*2').steps[0],'12 / 3 = 4');assert.equal(M.solve('10-4+2').steps[0],'10 - 4 = 6');
console.log('BODMAS: brackets, roots, powers, equal-rank left-to-right order and invalid brackets passed');
