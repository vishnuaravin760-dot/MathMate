const F=require('../app/src/main/assets/formula-book.js'),K=require('../app/src/main/assets/math/katex.min.js'),assert=require('node:assert/strict');
assert.equal(F.items.length,139);assert.equal(Object.keys(F.categories).length,8);assert.equal(new Set(F.items.map(f=>f.id)).size,139);
for(const f of F.items){assert.ok(F.categories[f.category]);assert.ok(f.title&&f.ml&&f.tex);assert.doesNotThrow(()=>K.renderToString(f.tex,{throwOnError:true,trust:false,maxExpand:500}),f.title);}
assert.ok(F.search('(a+b)').length>=2);assert.ok(F.search('square','algebra').length>=3);assert.equal(F.search('unlikelymissing12345').length,0);assert.equal(F.search('','integrals').length,16);
assert.ok(F.items.find(f=>f.title==='Power integral').note.includes('−1'));assert.ok(F.items.find(f=>f.title==='GP: infinite sum').note.includes('|r| < 1'));
console.log('139 formula entries, all KaTeX expressions, categories, search and key domain conditions checked.');
// Exact integer checks of the core school algebra identities across signed inputs.
for(let a=-5;a<=5;a++)for(let b=-5;b<=5;b++)for(let c=-2;c<=2;c++){
 const pairs=[[(a+b)**2,a*a+2*a*b+b*b],[(a-b)**2,a*a-2*a*b+b*b],[a*a-b*b,(a+b)*(a-b)],[(a+b)**3,a**3+3*a*a*b+3*a*b*b+b**3],[(a-b)**3,a**3-3*a*a*b+3*a*b*b-b**3],[a**3+b**3,(a+b)*(a*a-a*b+b*b)],[a**3-b**3,(a-b)*(a*a+a*b+b*b)],[(a+b+c)**2,a*a+b*b+c*c+2*a*b+2*b*c+2*c*a],[(c+a)*(c+b),c*c+(a+b)*c+a*b],[a*a+b*b,(a+b)**2-2*a*b],[a**3+b**3+c**3-3*a*b*c,(a+b+c)*(a*a+b*b+c*c-a*b-b*c-c*a)]];
 for(const [lhs,rhs]of pairs)assert.ok(lhs===rhs);
 const z=-a-b;assert.ok(a**3+b**3+z**3===3*a*b*z);
}
console.log('12 algebra identities checked over signed integer cases.');
