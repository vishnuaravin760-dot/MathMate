const P=require('../app/src/main/assets/practice.js'),assert=require('node:assert/strict');
let count=0;for(const topic of ['arithmetic','algebra','ap','geometry','trigonometry','differentiation','integration'])for(let i=0;i<100;i++){
 const p=P.make(topic),{a,b,c}=p.parameters;let expected;
 switch(topic){case 'arithmetic':expected=(a+b)*c;break;case 'algebra':expected=(Number(p.q.split('=')[1])-b)/a;break;case 'ap':expected=a+(c-1)*b;break;case 'geometry':expected=a*b;break;case 'trigonometry':expected=Math.sin(Number(p.q.match(/sin\((\d+)/)[1])*Math.PI/180);break;case 'differentiation':expected=a*b;break;case 'integration':expected=a*b*b/2;break;}
 assert.ok(Math.abs(p.answer-expected)<1e-9);assert.ok(p.hint&&p.hintMl&&p.q&&p.ml&&p.steps.length);count++;
}
console.log(count+' generated practice questions checked independently.');
