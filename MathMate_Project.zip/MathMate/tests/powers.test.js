const P=require('../app/src/main/assets/powers.js'),assert=require('node:assert/strict');
for(const [n,square,cube] of [['5','25','125'],['-5','25','-125'],['0','0','0'],['2.5','6.25','15.625'],['-0.25','0.0625','-0.015625'],['.1','0.01','0.001'],['0012.00','144','1728'],['-0.000','0','0'],['0.0000000001','0.00000000000000000001','0.000000000000000000000000000001'],['9007199254740993','81129638414606699710187514626049','730750818665451702490757660178213618792745926657']]){const r=P.calculate(n);assert.equal(r.square,square,n);assert.equal(r.cube,cube,n);}
for(let i=-100;i<=100;i++){const r=P.calculate(String(i));assert.equal(r.square,String(i*i));assert.equal(r.cube,String(i*i*i));}
const table=P.table('-3','3');assert.equal(table.length,7);assert.deepEqual(table[0],{number:'-3',square:'9',cube:'-27'});assert.deepEqual(table[6],{number:'3',square:'9',cube:'27'});
assert.equal(P.table('1','1000').length,1000);assert.equal(P.table('9999999999999999999999999','10000000000000000000000000').length,2);
for(const invalid of ['','abc','1e6','1,000','Infinity','1/2','9'.repeat(201),'<script>'])assert.throws(()=>P.calculate(invalid));
assert.throws(()=>P.table('3','1'));assert.throws(()=>P.table('1','1001'));assert.throws(()=>P.table('1.5','3'));
console.log('Exact squares/cubes checked: large integers, tiny decimals, negatives, 201 integer cases and bounded tables.');
for(const [input,root] of [['36','6'],['0','0'],['1','1'],['0.04','0.2'],['2.25','1.5'],['100000000000000000000','10000000000'],['-0','0']]){const r=P.squareRoot(input);assert.equal(r.root,root,input);assert.equal(r.exact,true,input);}
for(let i=0;i<200;i++){const r=P.squareRoot(String(i*i));assert.equal(r.root,String(i));assert.equal(r.exact,true);}
for(const input of ['2','3','6','123.456']){const r=P.squareRoot(input);assert.equal(r.exact,false);assert.ok(Math.abs(Number(r.root)-Math.sqrt(Number(input)))<1e-11);}
const tiny='0.'+'0'.repeat(197)+'1';assert.equal(P.squareRoot(tiny).root,'0.'+'0'.repeat(98)+'1');assert.equal(P.squareRoot(tiny).exact,true);
assert.throws(()=>P.squareRoot('-6'),/no real square root/);
console.log('Square roots checked: exact, irrational approximation, tiny/huge decimals and negative rejection.');
