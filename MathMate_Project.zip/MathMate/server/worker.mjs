// Set GEMINI_API_KEY and APP_TOKEN as Cloudflare Secrets, never in this file.
const reply = (body, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
});
export default {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (request.method === 'GET' && path === '/') return reply({ status: 'MathMate AI server ready' });
    if (request.method !== 'POST' || path !== '/solve') return reply({ error: 'Use POST /solve' }, 404);
    if (!env.GEMINI_API_KEY || !env.APP_TOKEN || env.APP_TOKEN.length < 20) return reply({ error: 'Server secrets not configured' }, 503);
    if (request.headers.get('Authorization') !== 'Bearer ' + env.APP_TOKEN) return reply({ error: 'Incorrect app access code' }, 401);
    if (!(request.headers.get('Content-Type') || '').includes('application/json')) return reply({ error: 'Send JSON' }, 415);
    let body;
    try {
      const reader = request.body?.getReader();
      if (!reader) return reply({ error: 'Missing question' }, 400);
      let size = 0; const chunks = [];
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > 2800000) { await reader.cancel(); return reply({ error: 'Image too large. Use a smaller photo.' }, 413); }
        chunks.push(value);
      }
      const bytes = new Uint8Array(size); let offset = 0;
      for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
      body = JSON.parse(new TextDecoder().decode(bytes));
      if (!body || typeof body !== 'object' || Array.isArray(body)) throw Error();
    } catch { return reply({ error: 'Invalid JSON request' }, 400); }
    const question = typeof body.question === 'string' ? body.question.trim() : '';
    if (question.length > 4000) return reply({ error: 'Use a shorter question' }, 400);
    const parts = [];
    if (body.image) {
      const img = body.image;
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(img.mimeType) || typeof img.data !== 'string' || !img.data.length || img.data.length > 2600000 || img.data.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(img.data)) return reply({ error: 'Invalid photo' }, 400);
      parts.push({ inlineData: { mimeType: img.mimeType, data: img.data } });
    }
    if (!question && !parts.length) return reply({ error: 'Enter a question or choose a photo' }, 400);
    parts.push({ text: question || 'Read the maths question in this image and solve it.' });
    const language = body.language === 'ml' ? 'simple Malayalam' : 'simple English';
    try {
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
        signal: AbortSignal.timeout(55000),
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: 'You are a maths tutor. Explain in ' + language + '. First restate the question you read. Give a clear answer with concise numbered calculation steps and check it. Carefully distinguish division, plus, multiplication, exponents and fractions. If a symbol or image is unclear, ask for clarification instead of guessing. If not a maths question, ask for a maths question. Do not claim every answer is certain. Use readable plain text.' }] },
          contents: [{ role: 'user', parts }],
          generationConfig: { maxOutputTokens: 4096 }
        })
      });
      if (!response.ok) {
        const code = response.status;
        return reply({ error: code === 429 ? 'Free AI limit reached. Try later; offline Solve still works.' : code === 400 || code === 401 || code === 403 ? 'Check the Gemini API key, account eligibility and free model access.' : code === 404 ? 'AI model unavailable for this account.' : 'AI service unavailable. Try later.' }, code === 429 ? 429 : 502);
      }
      const data = await response.json();
      const candidate = data.candidates?.[0];
      const answer = candidate?.content?.parts?.filter(p => !p.thought && typeof p.text === 'string').map(p => p.text).join('\n').trim();
      if (!answer) return reply({ error: 'No answer returned. Try rephrasing the maths question.' }, 422);
      return reply({ answer, incomplete: candidate.finishReason === 'MAX_TOKENS' });
    } catch { return reply({ error: 'AI connection timed out or failed. Please try again.' }, 504); }
  }
};
