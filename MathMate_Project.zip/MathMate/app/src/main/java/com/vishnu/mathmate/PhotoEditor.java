package com.vishnu.mathmate;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

// Local-only rectangular crop. No implicit upload or modification of Gallery originals.
final class PhotoEditor {
    interface Listener { void apply(Bitmap bitmap); void cancel(); }
    static void show(Activity activity, Bitmap bitmap, Listener listener) {
        Dialog dialog = new Dialog(activity);
        LinearLayout root = new LinearLayout(activity); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 20, 16, 20); root.setBackgroundColor(Color.rgb(18,17,29));
        TextView title = new TextView(activity);
        title.setText("Crop / Rotate photo\nചോദ്യത്തിന് ചുറ്റും വിരൽ വലിച്ച് box വരയ്ക്കുക.\nDrag a box around one question, then Use photo.");
        title.setTextColor(Color.rgb(231,219,250)); title.setTextSize(16); title.setPadding(8,8,8,14);
        root.addView(title);
        CropView crop = new CropView(activity, bitmap);
        root.addView(crop, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout tools = new LinearLayout(activity);
        for (String name : new String[]{"↻ Rotate", "Reset box"}) {
            Button button = new Button(activity); button.setText(name);
            tools.addView(button, new LinearLayout.LayoutParams(0,-2,1));
            button.setOnClickListener(v -> { try { if (name.startsWith("↻")) crop.rotate(); else crop.reset(); } catch (Exception | OutOfMemoryError e) { title.setText("Could not rotate. Try a smaller photo."); } });
        }
        root.addView(tools);
        LinearLayout actions = new LinearLayout(activity);
        Button cancel = new Button(activity); cancel.setText("Cancel");
        Button apply = new Button(activity); apply.setText("Use photo ✓");
        actions.addView(cancel,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(apply,new LinearLayout.LayoutParams(0,-2,1)); root.addView(actions);
        final boolean[] committed = {false};
        cancel.setOnClickListener(v -> dialog.dismiss());
        apply.setOnClickListener(v -> {
            try {
                Bitmap selected = crop.selected(); committed[0] = true; dialog.dismiss(); listener.apply(selected);
            } catch (Exception | OutOfMemoryError e) { title.setText("Choose a larger clear area, or cancel and try a smaller photo."); }
        });
        dialog.setContentView(root);
        dialog.setOnDismissListener(d -> { crop.release(); if (!committed[0]) listener.cancel(); });
        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (int)(activity.getResources().getDisplayMetrics().heightPixels * 0.88));
    }
    private static final class CropView extends View {
        private Bitmap image;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final RectF bounds = new RectF(), selection = new RectF();
        private float startX, startY;
        CropView(Activity context, Bitmap bitmap) { super(context); image = bitmap; setContentDescription("Drag a rectangle to select the question area"); }
        void reset() { selection.setEmpty(); invalidate(); }
        void rotate() {
            Matrix m = new Matrix(); m.setRotate(90);
            Bitmap rotated = Bitmap.createBitmap(image,0,0,image.getWidth(),image.getHeight(),m,true);
            if (rotated != image) image.recycle(); image = rotated; reset();
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas); canvas.drawColor(Color.rgb(32,40,37));
            float factor = Math.min((getWidth()-16f)/image.getWidth(),(getHeight()-16f)/image.getHeight());
            float width = image.getWidth()*factor, height = image.getHeight()*factor;
            bounds.set((getWidth()-width)/2,(getHeight()-height)/2,(getWidth()+width)/2,(getHeight()+height)/2);
            canvas.drawBitmap(image,null,bounds,paint);
            if (selection.isEmpty()) selection.set(bounds);
            paint.setColor(0x88000000); paint.setStyle(Paint.Style.FILL);
            canvas.drawRect(bounds.left,bounds.top,bounds.right,selection.top,paint);
            canvas.drawRect(bounds.left,selection.bottom,bounds.right,bounds.bottom,paint);
            canvas.drawRect(bounds.left,selection.top,selection.left,selection.bottom,paint);
            canvas.drawRect(selection.right,selection.top,bounds.right,selection.bottom,paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(4); paint.setColor(Color.rgb(196,160,255)); canvas.drawRect(selection,paint);
            paint.setStyle(Paint.Style.FILL);
        }
        private float clamp(float value,float min,float max) { return Math.max(min,Math.min(max,value)); }
        @Override public boolean onTouchEvent(MotionEvent event) {
            float x=clamp(event.getX(),bounds.left,bounds.right),y=clamp(event.getY(),bounds.top,bounds.bottom);
            switch(event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: startX=x;startY=y;return true;
                case MotionEvent.ACTION_MOVE:
                case MotionEvent.ACTION_UP:
                    if (Math.abs(x-startX)>12 && Math.abs(y-startY)>12) selection.set(Math.min(x,startX),Math.min(y,startY),Math.max(x,startX),Math.max(y,startY));
                    invalidate(); if(event.getActionMasked()==MotionEvent.ACTION_UP)performClick();return true;
                default:return true;
            }
        }
        @Override public boolean performClick(){super.performClick();return true;}
        Bitmap selected() {
            if(bounds.isEmpty())throw new IllegalStateException();
            RectF box=selection.isEmpty()?bounds:selection;
            int x=Math.max(0,Math.min(image.getWidth()-1,Math.round((box.left-bounds.left)*image.getWidth()/bounds.width())));
            int y=Math.max(0,Math.min(image.getHeight()-1,Math.round((box.top-bounds.top)*image.getHeight()/bounds.height())));
            int width=Math.max(1,Math.min(image.getWidth()-x,Math.round(box.width()*image.getWidth()/bounds.width())));
            int height=Math.max(1,Math.min(image.getHeight()-y,Math.round(box.height()*image.getHeight()/bounds.height())));
            Bitmap result=Bitmap.createBitmap(image,x,y,width,height);
            // Full-image crops can return the original. The editor retains its own bitmap.
            return result==image?image.copy(Bitmap.Config.ARGB_8888,false):result;
        }
        void release(){if(image!=null&&!image.isRecycled())image.recycle();}
    }
}
