package com.vishnu.mathmate;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.core.content.FileProvider;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int CAMERA = 41, GALLERY = 42;
    private WebView web;
    private TextRecognizer recognizer;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private Uri cameraUri;
    private File cameraFile;
    private boolean busy, pageReady, destroyed;
    private String pendingText, pendingError;
    private String lastPhoto;
    private boolean aiBusy;
    private final java.util.ArrayList<String> pendingScripts = new java.util.ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        if (state != null && state.getString("cameraPath") != null) {
            cameraFile = new File(state.getString("cameraPath"));
            cameraUri = FileProvider.getUriForFile(this, getPackageName()+".photos", cameraFile);
        }
        web = new WebView(this);
        web.setBackgroundColor(0xfff5f7f3);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setTextZoom(100);
        // This bridge is exposed only to packaged HTML; navigation and network loads are blocked.
        web.addJavascriptInterface(new PhotoBridge(), "PhotoReader");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) { return true; }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                for (String script : pendingScripts) web.evaluateJavascript(script, null);
                pendingScripts.clear();
                photoState();
                if (pendingText != null || pendingError != null) {
                    String text = pendingText, error = pendingError;
                    pendingText = null; pendingError = null;
                    deliver(text, error);
                }
            }
        });
        setContentView(web);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            web.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.ime());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
            web.requestApplyInsets();
        }
        try (InputStream in = getAssets().open("index.html"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            web.loadDataWithBaseURL("https://mathmate.invalid/", out.toString("UTF-8"), "text/html", null, null);
        } catch (Exception e) {
            android.widget.TextView error = new android.widget.TextView(this);
            error.setText("MathMate could not open. Please reinstall the APK.");
            error.setPadding(24,48,24,24); setContentView(error);
        }
    }

    public final class PhotoBridge {
        @JavascriptInterface public void openPhoto(final String source) {
            runOnUiThread(() -> pickPhoto("camera".equals(source)));
        }
        @JavascriptInterface public void configureAI() { runOnUiThread(() -> aiSettings()); }
        @JavascriptInterface public void clearPhoto() {
            runOnUiThread(() -> { if (!busy && !aiBusy) { lastPhoto = null; photoState(); } });
        }
        @JavascriptInterface public void solveAI(String question, String language, boolean includePhoto) {
            runOnUiThread(() -> requestAI(question, language, includePhoto));
        }
    }
    @SuppressWarnings("deprecation")
    private void pickPhoto(boolean camera) {
        if (destroyed || busy || aiBusy) return;
        busy = true;
        lastPhoto = null; photoState();
        try {
            if (camera) {
                File dir = new File(getCacheDir(), "photos");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Cannot create photo folder");
                cameraFile = File.createTempFile("question-", ".jpg", dir);
                cameraUri = FileProvider.getUriForFile(this, getPackageName()+".photos", cameraFile);
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                intent.setClipData(ClipData.newRawUri("Question photo", cameraUri));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, CAMERA);
            } else {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent, GALLERY);
            }
        } catch (Exception e) {
            cleanupPhoto();
            deliver(null, camera ? "Camera could not open. Try Gallery instead." : "Gallery could not open. Please try again.");
        }
    }
    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != CAMERA && request != GALLERY) return;
        if (result != RESULT_OK) { cleanupPhoto(); deliver(null, "Cancelled"); return; }
        final Uri uri = request == CAMERA ? cameraUri : data == null ? null : data.getData();
        if (uri == null) { cleanupPhoto(); deliver(null, "No image selected. Please try again."); return; }
        busy = true;
        worker.execute(() -> {
            try {
                final android.graphics.Bitmap bitmap = readPhoto(uri);
                ByteArrayOutputStream encoded = new ByteArrayOutputStream();
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, encoded);
                if (encoded.size() > 1900000) {
                    encoded.reset(); bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 55, encoded);
                }
                if (encoded.size() > 1900000) { bitmap.recycle(); throw new Exception("Photo too large"); }
                final String photo = android.util.Base64.encodeToString(encoded.toByteArray(), android.util.Base64.NO_WRAP);
                if (destroyed) { bitmap.recycle(); return; }
                runOnUiThread(() -> { lastPhoto = photo; photoState(); });
                InputImage image = InputImage.fromBitmap(bitmap, 0);
                recognizer.process(image)
                    .addOnSuccessListener(text -> runOnUiThread(() -> {
                        cleanupPhoto();
                        String recognized = text.getText().trim();
                        if (recognized.isEmpty()) deliver(null, "No clear text found. Photograph one printed question in good light.");
                        else if (recognized.length() > 4000) deliver(null, "Too much text. Photograph only one question.");
                        else deliver(recognized, null);
                    }))
                    .addOnFailureListener(e -> runOnUiThread(() -> {
                        cleanupPhoto(); deliver(null, "Could not read the photo. Try a clearer image.");
                    }))
                    .addOnCompleteListener(task -> bitmap.recycle());
            } catch (Exception | OutOfMemoryError e) {
                runOnUiThread(() -> { cleanupPhoto(); deliver(null, "Could not open the image. Try a smaller JPG or PNG."); });
            }
        });
    }

    private android.graphics.Bitmap readPhoto(Uri uri) throws Exception {
        android.graphics.BitmapFactory.Options opts = new android.graphics.BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) { android.graphics.BitmapFactory.decodeStream(in, null, opts); }
        if (opts.outWidth <= 0 || opts.outHeight <= 0) throw new Exception("Invalid image");
        opts.inSampleSize = 1;
        while (Math.max(opts.outWidth, opts.outHeight) / opts.inSampleSize > 2000) opts.inSampleSize *= 2;
        opts.inJustDecodeBounds = false;
        android.graphics.Bitmap bitmap;
        try (InputStream in = getContentResolver().openInputStream(uri)) { bitmap = android.graphics.BitmapFactory.decodeStream(in, null, opts); }
        if (bitmap == null) throw new Exception("Invalid image");
        int orientation = 1;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            orientation = new android.media.ExifInterface(in).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
        } catch (Exception ignored) { }
        android.graphics.Matrix m = new android.graphics.Matrix();
        switch (orientation) {
            case 2: m.setScale(-1, 1); break;
            case 3: m.setRotate(180); break;
            case 4: m.setScale(1, -1); break;
            case 5: m.setRotate(90); m.postScale(-1, 1); break;
            case 6: m.setRotate(90); break;
            case 7: m.setRotate(270); m.postScale(-1, 1); break;
            case 8: m.setRotate(270); break;
        }
        if (!m.isIdentity()) {
            android.graphics.Bitmap rotated = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
            if (rotated != bitmap) bitmap.recycle(); bitmap = rotated;
        }
        return bitmap;
    }
    private void js(String script) {
        if (destroyed) return;
        if (!pageReady) pendingScripts.add(script); else web.evaluateJavascript(script, null);
    }
    private void photoState() { js("window.setPhotoState(" + (lastPhoto != null) + ");"); }
    private void aiSettings() {
        if (destroyed || aiBusy || busy) return;
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL); layout.setPadding(36, 16, 36, 16);
        android.widget.TextView help = new android.widget.TextView(this);
        help.setText("Worker address is prefilled. Enter the APP_TOKEN you saved in Cloudflare. Do not enter the Gemini API key here.\n\nCloudflare-ൽ നൽകിയ APP_TOKEN നൽകുക. Gemini API key അല്ല.");
        android.widget.EditText address = new android.widget.EditText(this);
        address.setSingleLine(true); address.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        String oldUrl = getSharedPreferences("ai", 0).getString("url", AiClient.DEFAULT_URL);
        address.setText(oldUrl);
        android.widget.EditText token = new android.widget.EditText(this);
        token.setSingleLine(true); token.setHint("APP_TOKEN (20+ characters)");
        token.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO);
        layout.addView(help); layout.addView(address); layout.addView(token);
        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this).setTitle("AI Settings / AI ക്രമീകരണം")
            .setView(layout).setNegativeButton("Cancel", null).setNeutralButton("Clear settings", (d, which) -> {
                getSharedPreferences("ai", 0).edit().clear().apply();
                android.widget.Toast.makeText(this, "AI settings cleared", android.widget.Toast.LENGTH_SHORT).show();
            }).setPositiveButton("Save", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                String newUrl = AiClient.checkedUrl(address.getText().toString());
                String access = token.getText().toString().trim();
                if (access.isEmpty() && newUrl.equals(oldUrl)) access = AiClient.loadToken(this);
                AiClient.save(this, newUrl, access);
                dialog.dismiss(); android.widget.Toast.makeText(this, "AI settings saved", android.widget.Toast.LENGTH_SHORT).show();
            } catch (Exception e) { token.setError(e.getMessage()); }
        }));
        dialog.show();
        dialog.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
    }
    private void requestAI(String question, String language, boolean includePhoto) {
        if (destroyed || aiBusy || busy) { aiResult(null, "Please wait for the current task.", false); return; }
        final String text = question == null ? "" : question.trim();
        final String photo = includePhoto ? lastPhoto : null;
        if (text.length() > 4000) { aiResult(null, "Use a question under 4000 characters.", false); return; }
        if (includePhoto && photo == null) { aiResult(null, "Choose the photo again.", false); return; }
        if (text.isEmpty() && photo == null) { aiResult(null, "Enter a question or choose a photo.", false); return; }
        aiBusy = true;
        worker.execute(() -> {
            try {
                String token = AiClient.loadToken(this);
                if (token.isEmpty()) throw new Exception("Open AI Settings and enter your APP_TOKEN first.");
                String address = getSharedPreferences("ai", 0).getString("url", AiClient.DEFAULT_URL);
                JSONObject result = AiClient.solve(address, token, text, language, photo);
                runOnUiThread(() -> aiResult(result.optString("answer"), null, result.optBoolean("incomplete", false)));
            } catch (Exception e) {
                // Never expose the token, request body or raw network diagnostics to the page.
                String message = e instanceof java.io.IOException ? "Connection failed. Check internet and Worker address, then try again." : e.getMessage();
                runOnUiThread(() -> aiResult(null, message == null ? "Could not connect to AI. Check AI Settings." : message, false));
            }
        });
    }
    private void aiResult(String answer, String error, boolean incomplete) {
        aiBusy = false;
        js("window.receiveAI(" + (answer == null ? "null" : JSONObject.quote(answer)) + "," + (error == null ? "null" : JSONObject.quote(error)) + "," + incomplete + ");");
    }

    private void deliver(String text, String error) {
        busy = false;
        if (destroyed) return;
        if (!pageReady) { pendingText = text; pendingError = error; return; }
        String payload = "window.receiveOCR(" + (text == null ? "null" : JSONObject.quote(text)) + "," + (error == null ? "null" : JSONObject.quote(error)) + ");";
        web.evaluateJavascript(payload, null);
    }
    private void cleanupPhoto() {
        if (cameraUri != null) revokeUriPermission(cameraUri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if (cameraFile != null) cameraFile.delete();
        cameraUri = null; cameraFile = null;
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        if (cameraFile != null) state.putString("cameraPath", cameraFile.getAbsolutePath());
        super.onSaveInstanceState(state);
    }
    @Override protected void onDestroy() {
        destroyed = true;
        worker.shutdownNow();
        if (recognizer != null) recognizer.close();
        if (web != null) { web.removeJavascriptInterface("PhotoReader"); web.destroy(); }
        super.onDestroy();
    }
}
