package com.vishnu.mathmate;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.core.content.FileProvider;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int CAMERA = 41, GALLERY = 42;
    private WebView web;
    private TextRecognizer recognizer;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private Uri cameraUri;
    private File cameraFile;
    private boolean busy, pageReady, destroyed;
    private String pendingText, pendingError;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        if (state != null && state.getString("cameraPath") != null) {
            cameraFile = new File(state.getString("cameraPath"));
            cameraUri = FileProvider.getUriForFile(this, getPackageName()+".photos", cameraFile);
        }
        web = new WebView(this);
        web.setBackgroundColor(0xfff5f7f3);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setTextZoom(100);
        // This bridge is exposed only to packaged HTML; navigation and network loads are blocked.
        web.addJavascriptInterface(new PhotoBridge(), "PhotoReader");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) { return true; }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (pendingText != null || pendingError != null) {
                    String text = pendingText, error = pendingError;
                    pendingText = null; pendingError = null;
                    deliver(text, error);
                }
            }
        });
        setContentView(web);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            web.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.ime());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
            web.requestApplyInsets();
        }
        try (InputStream in = getAssets().open("index.html"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            web.loadDataWithBaseURL("https://mathmate.invalid/", out.toString("UTF-8"), "text/html", null, null);
        } catch (Exception e) {
            android.widget.TextView error = new android.widget.TextView(this);
            error.setText("MathMate could not open. Please reinstall the APK.");
            error.setPadding(24,48,24,24); setContentView(error);
        }
    }

    public final class PhotoBridge {
        @JavascriptInterface public void openPhoto(final String source) {
            runOnUiThread(() -> pickPhoto("camera".equals(source)));
        }
    }
    @SuppressWarnings("deprecation")
    private void pickPhoto(boolean camera) {
        if (destroyed || busy) return;
        busy = true;
        try {
            if (camera) {
                File dir = new File(getCacheDir(), "photos");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Cannot create photo folder");
                cameraFile = File.createTempFile("question-", ".jpg", dir);
                cameraUri = FileProvider.getUriForFile(this, getPackageName()+".photos", cameraFile);
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                intent.setClipData(ClipData.newRawUri("Question photo", cameraUri));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, CAMERA);
            } else {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent, GALLERY);
            }
        } catch (Exception e) {
            cleanupPhoto();
            deliver(null, camera ? "Camera could not open. Try Gallery instead." : "Gallery could not open. Please try again.");
        }
    }
    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != CAMERA && request != GALLERY) return;
        if (result != RESULT_OK) { cleanupPhoto(); deliver(null, "Cancelled"); return; }
        final Uri uri = request == CAMERA ? cameraUri : data == null ? null : data.getData();
        if (uri == null) { cleanupPhoto(); deliver(null, "No image selected. Please try again."); return; }
        busy = true;
        worker.execute(() -> {
            try {
                InputImage image = InputImage.fromFilePath(this, uri);
                if (destroyed) return;
                recognizer.process(image)
                    .addOnSuccessListener(text -> runOnUiThread(() -> {
                        cleanupPhoto();
                        String recognized = text.getText().trim();
                        if (recognized.isEmpty()) deliver(null, "No clear text found. Photograph one printed question in good light.");
                        else if (recognized.length() > 4000) deliver(null, "Too much text. Photograph only one question.");
                        else deliver(recognized, null);
                    }))
                    .addOnFailureListener(e -> runOnUiThread(() -> {
                        cleanupPhoto(); deliver(null, "Could not read the photo. Try a clearer image.");
                    }));
            } catch (Exception | OutOfMemoryError e) {
                runOnUiThread(() -> { cleanupPhoto(); deliver(null, "Could not open the image. Try a smaller JPG or PNG."); });
            }
        });
    }
    private void deliver(String text, String error) {
        busy = false;
        if (destroyed) return;
        if (!pageReady) { pendingText = text; pendingError = error; return; }
        String payload = "window.receiveOCR(" + (text == null ? "null" : JSONObject.quote(text)) + "," + (error == null ? "null" : JSONObject.quote(error)) + ");";
        web.evaluateJavascript(payload, null);
    }
    private void cleanupPhoto() {
        if (cameraUri != null) revokeUriPermission(cameraUri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if (cameraFile != null) cameraFile.delete();
        cameraUri = null; cameraFile = null;
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        if (cameraFile != null) state.putString("cameraPath", cameraFile.getAbsolutePath());
        super.onSaveInstanceState(state);
    }
    @Override protected void onDestroy() {
        destroyed = true;
        worker.shutdownNow();
        if (recognizer != null) recognizer.close();
        if (web != null) { web.removeJavascriptInterface("PhotoReader"); web.destroy(); }
        super.onDestroy();
    }
}
