package com.vishnu.mathmate;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;

final class AiClient {
    static final String DEFAULT_URL = "https://mathmate-aii.vishnuaravin760.workers.dev";
    private static final String ALIAS = "MathMateAccessCode";
    static String checkedUrl(String value) throws Exception {
        URI u = new URI(value.trim());
        String host = u.getHost();
        if (!"https".equalsIgnoreCase(u.getScheme()) || host == null || !host.endsWith(".workers.dev") || u.getUserInfo() != null || (u.getPort() != -1 && u.getPort() != 443) || u.getQuery() != null || u.getFragment() != null || !(u.getPath().isEmpty() || "/".equals(u.getPath())))
            throw new Exception("Use your HTTPS workers.dev address without /solve.");
        return "https://" + host;
    }
    private static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (store.containsAlias(ALIAS)) return (SecretKey)store.getKey(ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return generator.generateKey();
    }
    static String loadToken(Context context) throws Exception {
        String value = context.getSharedPreferences("ai", 0).getString("encryptedToken", "");
        if (value.isEmpty()) return "";
        String[] pieces = value.split(":");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(pieces[0], Base64.NO_WRAP)));
        return new String(cipher.doFinal(Base64.decode(pieces[1], Base64.NO_WRAP)), "UTF-8");
    }
    static void save(Context context, String url, String token) throws Exception {
        url = checkedUrl(url);
        if (token.length() < 20 || token.length() > 256 || !token.matches("[\\x21-\\x7E]+"))
            throw new Exception("Access code: use 20–256 English letters, numbers or symbols, without spaces.");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key());
        String encrypted = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(cipher.doFinal(token.getBytes("UTF-8")), Base64.NO_WRAP);
        if (!context.getSharedPreferences("ai", 0).edit().putString("url", url).putString("encryptedToken", encrypted).commit())
            throw new Exception("Could not save settings. Please try again.");
    }
    static JSONObject solve(String url, String token, String question, String language, String photo, boolean learning) throws Exception {
        String formatting = "\nFor mathematical notation use LaTeX \\(...\\) inline or \\[...\\] for display, with ordinary teaching text outside. Do not wrap the whole answer in a code fence.";
        String teaching = "\nLEARNING MODE: Teach a beginner who needs time. Use short sentences in the requested language. Never skip arithmetic or assume prior knowledge. Define unfamiliar maths words gently. No patronising language. Use these exact section markers on separate lines, with the teaching body after each: [QUESTION] restate the problem; [GIVEN] explain supplied values and symbols; [GOAL] what to find; [FORMULA] formula or rule, explain its letters and why it applies; [STEP] one tiny action, substitute actual values, show its calculation and explain WHY. Repeat [STEP] for each small action; [CHECK] verify by substitution or another valid check; [ANSWER] concise final result with units. Keep the markers in English but all teaching text in the requested language. If asked to simplify just one part, teach only that part in this structure. If the image or information is unclear, ask for clarification instead of guessing.";
        if (learning) {
            if (question.length() + formatting.length() + teaching.length() > 4000)
                throw new Exception("For step-by-step learning, use a shorter question or photo (under 2800 characters).");
            question += teaching;
        }
        if (question.length() + formatting.length() <= 4000) question += formatting;
        JSONObject body = new JSONObject().put("question", question).put("language", "ml".equals(language) ? "ml" : "en");
        if (photo != null) body.put("image", new JSONObject().put("mimeType", "image/jpeg").put("data", photo));
        byte[] bytes = body.toString().getBytes("UTF-8");
        HttpsURLConnection conn = (HttpsURLConnection)new URL(checkedUrl(url) + "/solve").openConnection();
        try {
            conn.setInstanceFollowRedirects(false);
            conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(65000);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + token);
            conn.setDoOutput(true); conn.setFixedLengthStreamingMode(bytes.length);
            try (java.io.OutputStream out = conn.getOutputStream()) { out.write(bytes); }
            int status = conn.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
            if (stream == null) throw new Exception("Server returned HTTP " + status + ". Check AI Settings.");
            ByteArrayOutputStream data = new ByteArrayOutputStream();
            try (InputStream in = stream) {
                byte[] buffer = new byte[4096]; int read;
                while ((read = in.read(buffer)) != -1) {
                    if (data.size() + read > 200000) throw new Exception("Server answer too large.");
                    data.write(buffer, 0, read);
                }
            }
            JSONObject response;
            try { response = new JSONObject(data.toString("UTF-8")); }
            catch (Exception e) { throw new Exception("Server response is not JSON. Check the Worker code and address."); }
            if (status < 200 || status >= 300) throw new Exception(response.optString("error", "Server error " + status));
            if (response.optString("answer", "").trim().isEmpty()) throw new Exception("No AI answer returned.");
            return response;
        } finally { conn.disconnect(); }
    }
}
