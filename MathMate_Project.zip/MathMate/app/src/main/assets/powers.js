'use strict';
// Fixed-point decimal arithmetic. Integers and decimals are never converted to Number.
const ExactPowers=(()=>{
 function available(){if(typeof BigInt!=='function')throw Error('Update Android System WebView to use exact Square & Cube.');}
 function parse(value,integer=false){
  available();let s=String(value).trim().replace(/[−–]/g,'-');
  if(!s)throw Error('Enter a number.');
  if(s.length>203||!(/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/).test(s))throw Error('Enter a plain number, up to 200 digits. Use a decimal point, without commas.');
  if(integer&&!/^[+-]?\d+$/.test(s))throw Error('Use whole numbers for the table.');
  const negative=s[0]==='-';s=s.replace(/^[+-]/,'');const pair=s.split('.');
  const digits=pair.join('');if(digits.length>200)throw Error('Use at most 200 digits.');
  const scale=(pair[1]||'').length;let valueInt=BigInt(digits||'0');if(negative)valueInt=-valueInt;
  return {value:valueInt,scale};
 }
 function format(value,scale){let s=value.toString(),negative=s[0]==='-';if(negative)s=s.slice(1);if(scale){s=s.padStart(scale+1,'0');s=s.slice(0,-scale)+'.'+s.slice(-scale);s=s.replace(/0+$/,'').replace(/\.$/,'');}return (negative&&value!==BigInt(0)?'-':'')+s;}
 function calculate(text){const n=parse(text),square=n.value*n.value,cube=square*n.value;return {number:format(n.value,n.scale),square:format(square,n.scale*2),cube:format(cube,n.scale*3)};}
 function table(from,to){const a=parse(from,true).value,b=parse(to,true).value,length=b-a+BigInt(1);if(length<=BigInt(0))throw Error('The last number must be greater than or equal to the first.');if(length>BigInt(1000))throw Error('Show at most 1,000 rows at a time.');const rows=[];for(let n=a;n<=b;n+=BigInt(1))rows.push({number:n.toString(),square:(n*n).toString(),cube:(n*n*n).toString()});return rows;}
 function integerRoot(n){if(n<BigInt(2))return n;let x=BigInt(1)<<BigInt(Math.ceil(n.toString(2).length/2));while(true){const next=(x+n/x)/BigInt(2);if(next>=x)return x;x=next;}}
 function squareRoot(text){const n=parse(text);if(n.value<BigInt(0))throw Error('Negative numbers have no real square root.');const scale=Math.max(12,Math.ceil(n.scale/2)+12);const scaled=n.value*(BigInt(10)**BigInt(2*scale-n.scale));const root=integerRoot(scaled);return {number:format(n.value,n.scale),root:format(root,scale),exact:root*root===scaled};}
 return {calculate,table,squareRoot};
})();
if(typeof module!=='undefined')module.exports=ExactPowers;
