'use strict';
const LessonSteps=(()=>{
 function parse(text){
  if(typeof text!=='string'||text.length>200000)return [];
  const pattern=/^\s*\[(QUESTION|GIVEN|GOAL|FORMULA|STEP(?:\s+\d+)?|CHECK|ANSWER)\]\s*/gmi;
  const matches=[...text.matchAll(pattern)];
  if(matches.length>=2){const result=[];const intro=text.slice(0,matches[0].index).trim();if(intro&&!/^```\w*$/.test(intro))result.push({type:'INTRO',body:intro});matches.slice(0,40).forEach((m,i)=>{let body=text.slice(m.index+m[0].length,i+1<matches.length?matches[i+1].index:text.length).trim().replace(/\n?```\s*$/,'');if(body)result.push({type:m[1].toUpperCase().startsWith('STEP')?'STEP':m[1].toUpperCase(),body});});return result.length>=2?result:[];}
  // Tolerate a model that uses normal numbered step headings instead of the markers.
  const fallback=/^\s*(?:#{1,4}\s*)?(?:Step|ഘട്ടം)\s*\d+\s*[:.)-]\s*/gmi, steps=[...text.matchAll(fallback)];
  if(steps.length<2)return [];
  const sections=[],intro=text.slice(0,steps[0].index).trim();if(intro)sections.push({type:'INTRO',body:intro});steps.slice(0,40).forEach((m,i)=>{const body=text.slice(m.index+m[0].length,i+1<steps.length?steps[i+1].index:text.length).trim();if(body)sections.push({type:'STEP',body});});return sections;
 }
 return {parse};
})();
if(typeof module!=='undefined')module.exports=LessonSteps;
