'use strict';
let lessonSections=[],lessonIndex=0,lessonAll=false;
try{$('learningMode').checked=localStorage.getItem('mathmate-learning')!=='off';}catch(e){$('learningMode').checked=true;}
function sendAI(question,language,includePhoto){
 if($('learningMode').checked&&typeof window.PhotoReader.solveLearningAI==='function')window.PhotoReader.solveLearningAI(question,language,includePhoto);
 else window.PhotoReader.solveAI(question,language,includePhoto);
}
const lessonTitles={INTRO:['Let’s begin','ആരംഭിക്കാം'],QUESTION:['Read the question','ചോദ്യം വായിക്കാം'],GIVEN:['What do we know?','എന്തെല്ലാം നൽകിയിട്ടുണ്ട്?'],GOAL:['What must we find?','എന്താണ് കണ്ടെത്തേണ്ടത്?'],FORMULA:['The formula or rule','ഉപയോഗിക്കുന്ന formula / നിയമം'],STEP:['One small step','ഒരു ചെറിയ ഘട്ടം'],CHECK:['Let’s check','പരിശോധിക്കാം'],ANSWER:['The answer','ഉത്തരം']};
function clearLesson(){lessonSections=[];lessonIndex=0;lessonAll=false;$('lessonPager').hidden=true;$('answer').hidden=false;$('steps').hidden=false;}
function renderLesson(){
 if(!lessonSections.length)return;
 $('lessonCards').replaceChildren();const selected=lessonAll?lessonSections:[lessonSections[lessonIndex]];
 selected.forEach(section=>{const card=document.createElement('article');card.className='lesson-card';const title=document.createElement('h3');title.textContent=(lessonTitles[section.type]||lessonTitles.STEP)[ml?1:0];const body=document.createElement('div');body.className='lesson-body';body.textContent=section.body;card.append(title,body);$('lessonCards').append(card);drawMath(body);});
 $('lessonPosition').textContent=lessonAll?tr('All steps','എല്ലാ ഘട്ടങ്ങളും'):tr(`Part ${lessonIndex+1} of ${lessonSections.length}`,`ഭാഗം ${lessonIndex+1} / ${lessonSections.length}`);
 $('lessonShowAll').textContent=lessonAll?tr('One at a time','ഒന്നായി കാണുക'):tr('Show all','എല്ലാം കാണുക');
 $('lessonNavigation').hidden=lessonAll;$('lessonBack').disabled=lessonIndex===0;$('lessonNext').disabled=lessonIndex===lessonSections.length-1;
 $('lessonSimplify').disabled=aiWorking||scanning||lessonAll;$('lessonPager').hidden=false;$('answer').hidden=true;$('steps').hidden=true;
}
function startLesson(sections){if(!sections||sections.length<2)return;lessonSections=sections;lessonIndex=0;lessonAll=false;renderLesson();}
$('lessonBack').onclick=()=>{if(lessonIndex>0){lessonIndex--;renderLesson();}};
$('lessonNext').onclick=()=>{if(lessonIndex<lessonSections.length-1){lessonIndex++;renderLesson();}};
$('lessonShowAll').onclick=()=>{lessonAll=!lessonAll;renderLesson();};
function offlineLessons(question,result){
 const sections=[{type:'QUESTION',body:question}],f=MathMate.fmt;
 const add=(type,body)=>sections.push({type,body});
 try{
  if(!question.includes('=')){
   const tree=MathMate.parse(question);
   add('GIVEN',tr('The question gives us numbers and operation signs. A bracket groups numbers that must be worked out together.','ചോദ്യത്തിൽ സംഖ്യകളും കണക്കിന്റെ ചിഹ്നങ്ങളുമുണ്ട്. Bracket-ലുള്ള ഭാഗം ഒന്നിച്ച് കണക്കാക്കണം.'));
   add('GOAL',tr('Find the value of the whole calculation.','മുഴുവൻ കണക്കിന്റെ മൂല്യം കണ്ടെത്തണം.'));
   add('FORMULA',tr('BODMAS: brackets first; then powers/roots; then × and ÷ together from LEFT TO RIGHT; then + and − together from LEFT TO RIGHT. D is not always before M; A is not always before S.','BODMAS: ആദ്യം brackets; ശേഷം powers/roots; ശേഷം ×, ÷ ഒരേ മുൻഗണനയിൽ ഇടത്തുനിന്ന് വലത്തേക്ക്; അവസാനം +, − ഒരേ മുൻഗണനയിൽ ഇടത്തുനിന്ന് വലത്തേക്ക്. D എപ്പോഴും M-ന് മുമ്പല്ല; A എപ്പോഴും S-ന് മുമ്പല്ല.'));
   function walk(node){
    if(node.a)walk(node.a);if(node.b)walk(node.b);
    if(node.a&&node.b){const a=MathMate.calc(node.a),b=MathMate.calc(node.b),v=MathMate.calc(node);const sign={'+':'+','-':'−','*':'×','/':'÷','^':'^'}[node.k]||node.k;
     const reason={'+':tr('Add these two values.','ഈ രണ്ട് മൂല്യങ്ങളും കൂട്ടുക.'),'-':tr('Subtract the second value from the first.','ആദ്യ മൂല്യത്തിൽ നിന്ന് രണ്ടാമത്തേത് കുറയ്ക്കുക.'),'*':tr('Multiply these two values.','ഈ രണ്ട് മൂല്യങ്ങളും ഗുണിക്കുക.'),'/':tr('Divide the first value by the second.','ആദ്യ മൂല്യത്തെ രണ്ടാമത്തേത് കൊണ്ട് ഹരിക്കുക.'),'^':tr('A power tells how many times the base is multiplied by itself for a positive whole-number exponent.','പോസിറ്റീവ് പൂർണ്ണസംഖ്യാ ഘാതം, അടിസ്ഥാന സംഖ്യയെ എത്ര തവണ ഗുണിക്കണമെന്ന് പറയുന്നു.')};
     add('STEP',`${f(a)} ${sign} ${f(b)} = ${f(v)}\n\n`+reason[node.k]+'\n'+tr('We simplify this part before moving to the next operation.','അടുത്ത കണക്കിലേക്ക് പോകുന്നതിന് മുമ്പ് ഈ ഭാഗം ലളിതമാക്കുന്നു.'));
    }else if(node.k==='fn'){const v=MathMate.calc(node);add('STEP',`${node.f}(${f(MathMate.calc(node.a))}) = ${f(v)}\n\n`+(node.f==='sqrt'?tr('A square root is the non-negative number whose square is the input.','വർഗമൂലം: സ്വയം ഗുണിക്കുമ്പോൾ നൽകിയ സംഖ്യ കിട്ടുന്ന നെഗറ്റീവ് അല്ലാത്ത സംഖ്യ.'):tr('Apply this function to the value in its brackets. Trigonometric angles here use degrees.','Bracket-ലുള്ള മൂല്യത്തിന് ഈ function പ്രയോഗിക്കുക. ഇവിടെ trigonometry ഡിഗ്രിയിലാണ്.')));}
    else if(node.k==='neg')add('STEP',tr('Put a minus sign in front of this value: ','ഈ മൂല്യത്തിന് മുന്നിൽ minus നൽകുക: ')+f(MathMate.calc(node)));
   }
   walk(tree);
   if(tree.a&&tree.b){const a=MathMate.calc(tree.a),b=MathMate.calc(tree.b),v=MathMate.calc(tree);let check;
    if(tree.k==='/')check=`${f(v)} × ${f(b)} = ${f(v*b)} ≈ ${f(a)}`;
    if(tree.k==='+')check=`${f(v)} − ${f(b)} = ${f(v-b)} ≈ ${f(a)}`;
    if(tree.k==='-')check=`${f(v)} + ${f(b)} = ${f(v+b)} ≈ ${f(a)}`;
    if(tree.k==='*'&&b!==0)check=`${f(v)} ÷ ${f(b)} = ${f(v/b)} ≈ ${f(a)}`;
    if(check)add('CHECK',tr('Undo the final operation to check:\n','അവസാന കണക്കിന്റെ വിപരീതം ചെയ്ത് പരിശോധിക്കാം:\n')+check+tr('\nSmall decimal differences can be due to rounding.','\nചെറിയ ദശാംശ വ്യത്യാസം rounding കാരണം വരാം.'));
   }
  }else{
   add('GIVEN',tr('An equation says that both sides have the same value. x (and sometimes y) represents a number we do not know yet. For example, 2x means 2 × x.','സമവാക്യം എന്നാൽ ഇരുവശത്തിനും ഒരേ മൂല്യമെന്നാണ്. x (ചിലപ്പോൾ y) അറിയാത്ത സംഖ്യയെ സൂചിപ്പിക്കുന്നു. ഉദാഹരണം: 2x എന്നാൽ 2 × x.'));
   add('GOAL',tr('Find the unknown value or values that make the equation true.','സമവാക്യം ശരിയാക്കുന്ന അറിയാത്ത മൂല്യങ്ങൾ കണ്ടെത്തണം.'));
   let taughtLinear=false;const rows=question.split(/[;\n]+/).map(s=>s.trim()).filter(Boolean);
   if(rows.length===1&&Array.isArray(result.values)&&result.values.length===1){
    const pair=rows[0].split('='),left=MathMate.parse(pair[0]),right=MathMate.parse(pair[1]);
    const lc=MathMate.calc(left,{x:0}),rc=MathMate.calc(right,{x:0}),la=MathMate.calc(left,{x:1})-lc,ra=MathMate.calc(right,{x:1})-rc;
    const linear=Math.abs(MathMate.calc(left,{x:2})-(2*la+lc))<1e-10&&Math.abs(MathMate.calc(right,{x:2})-(2*ra+rc))<1e-10;
    const coef=la-ra,target=rc-lc;
    if(linear&&coef!==0){
     taughtLinear=true;
     add('FORMULA',tr('Keep both sides equal: add or subtract the SAME number on both sides, then divide both sides by the SAME nonzero number.','ഇരുവശവും തുല്യമായി നിലനിർത്തണം: ഒരേ സംഖ്യ ഇരുവശത്തും കൂട്ടുകയോ കുറയ്ക്കുകയോ ചെയ്യുക. ശേഷം പൂജ്യമല്ലാത്ത ഒരേ സംഖ്യ കൊണ്ട് ഇരുവശവും ഹരിക്കുക.'));
     if(ra===0&&lc!==0){const action=lc>0?tr('Subtract ','കുറയ്ക്കേണ്ടത്: '):tr('Add ','കൂട്ടേണ്ടത്: ');add('STEP',action+f(Math.abs(lc))+tr(' on BOTH sides.\n',' ഇരുവശത്തും.\n')+question+'\n'+`${f(la)}x = ${f(rc)} ${lc>0?'−':'+'} ${f(Math.abs(lc))} = ${f(target)}`+'\n\n'+tr('Why? We remove the extra constant so the term containing x is alone.','കാരണം: x ഉള്ള പദം മാത്രം കിട്ടാൻ കൂടെയുള്ള സ്ഥിരസംഖ്യ ഒഴിവാക്കുന്നു.'));}
     else if(ra!==0)add('STEP',`(${f(la)} − ${f(ra)})x = ${f(rc)} − (${f(lc)})\n${f(coef)}x = ${f(target)}\n\n`+tr('Collect x terms together and constants together by doing the same subtraction on both sides.','ഇരുവശത്തും ഒരേ കുറയ്ക്കൽ നടത്തി x പദങ്ങൾ ഒരുമിച്ചും സ്ഥിരസംഖ്യകൾ ഒരുമിച്ചും കൊണ്ടുവരുന്നു.'));
     add('STEP',`${f(coef)}x = ${f(target)}\nx = ${f(target)} ÷ (${f(coef)}) = ${f(result.values[0])}\n\n`+tr(`Divide BOTH sides by ${f(coef)}. The coefficient is the number multiplying x; division undoes that multiplication.`,`ഇരുവശവും ${f(coef)} കൊണ്ട് ഹരിക്കുക. x-നെ ഗുണിക്കുന്ന സംഖ്യയാണ് ഗുണകം. ആ ഗുണനം ഒഴിവാക്കാൻ ഹരിക്കുന്നു.`));
    }
   }
   if(!taughtLinear){add('FORMULA',tr('Use the equation method shown below. For a quadratic ax² + bx + c = 0, x = (−b ± √(b² − 4ac)) / (2a), with a ≠ 0. For more teaching detail, use Solve with AI.','താഴെ കാണുന്ന സമവാക്യ രീതി ഉപയോഗിക്കുക. Quadratic ax² + bx + c = 0-ന് x = (−b ± √(b² − 4ac)) / (2a), a ≠ 0. കൂടുതൽ വിശദീകരണത്തിന് Solve with AI ഉപയോഗിക്കാം.'));for(const step of result.steps||[])add('STEP',step);}
   if(Array.isArray(result.values)&&result.values.length){
    const candidates=rows.length===2?[{x:result.values[0],y:result.values[1]}]:result.values.map(x=>({x}));const checks=[];
    for(const env of candidates)for(const row of rows){const parts=row.split('='),a=MathMate.calc(MathMate.parse(parts[0]),env),b=MathMate.calc(MathMate.parse(parts[1]),env);if(Math.abs(a-b)<=1e-8*Math.max(1,Math.abs(a),Math.abs(b)))checks.push(Object.entries(env).map(([k,v])=>k+' = '+f(v)).join(', ')+' → '+f(a)+' = '+f(b));}
    if(checks.length)add('CHECK',tr('Put the answer back into the original equation:\n','ഉത്തരം ആദ്യ സമവാക്യത്തിൽ നൽകി പരിശോധിക്കാം:\n')+checks.join('\n')+'\n\n'+tr('Both sides agree, within decimal rounding.','ദശാംശ rounding പരിഗണിക്കുമ്പോൾ ഇരുവശവും തുല്യമാണ്.'));
   }
  }
  add('ANSWER',result.answer);
  return sections;
 }catch(e){return [...sections,...(result.steps||[]).map(body=>({type:'STEP',body})),{type:'ANSWER',body:result.answer}];}
}
const resultBeforeLearning=showResult;showResult=function(result){resultBeforeLearning(result);clearLesson();if($('learningMode').checked&&Array.isArray(result.steps)&&result.steps.length)startLesson(offlineLessons($('question').value.trim(),result));};
const aiBeforeLearning=showAI;showAI=function(answer,incomplete){aiBeforeLearning(answer,incomplete);if($('learningMode').checked)startLesson(LessonSteps.parse(answer));};
const resetBeforeLearning=resetResult;resetResult=function(){resetBeforeLearning();clearLesson();};
const controlsBeforeLearning=controls;controls=function(){controlsBeforeLearning();$('learningMode').disabled=aiWorking||scanning;$('lessonSimplify').disabled=aiWorking||scanning||lessonAll;};
$('learningMode').onchange=()=>{try{localStorage.setItem('mathmate-learning',$('learningMode').checked?'on':'off');}catch(e){}if(currentRecord&&!$('result').hidden){const r={...currentRecord};if(r.ai)showAI(r.answer,false);else showResult({answer:r.answer,steps:r.steps,note:r.note});}};
$('lessonSimplify').onclick=()=>{
 if(!currentRecord||!lessonSections.length||aiWorking||scanning||lessonAll)return;
 if(!window.PhotoReader||typeof window.PhotoReader.solveAI!=='function'){error(new Error('Use the installed Android app to ask AI.'));return;}
 const part=lessonSections[lessonIndex];aiQuestion='Teach only this part more simply, with short sentences, one small numeric example and the reason for every small move. Explain any unfamiliar words.\nOriginal problem: '+currentRecord.q.slice(0,600)+'\nPart needing help: '+part.body.slice(0,1100);
 aiWorking=true;controls();$('aiStatus').hidden=false;$('aiStatus').textContent=tr('Preparing a simpler explanation…','കൂടുതൽ ലളിതമായ വിശദീകരണം തയ്യാറാക്കുന്നു…');
 try{sendAI(aiQuestion,ml?'ml':'en',false);}catch(e){window.receiveAI(null,'Could not ask AI. Please try again.',false);}
};
