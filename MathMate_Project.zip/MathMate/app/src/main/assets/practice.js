'use strict';
const PracticeMath = (()=>{
 function make(topic='arithmetic',random=Math.random){
  const n=(a,b)=>Math.floor(random()*(b-a+1))+a;
  let a=n(2,12),b=n(2,9),c=n(2,8),v,q,m,h,hm,s,sm;
  switch(topic){
   case 'algebra': v=n(2,10);q=`Solve: ${a}x + ${b} = ${a*v+b}`;m=`പരിഹരിക്കുക: ${a}x + ${b} = ${a*v+b}`;h='Subtract the constant, then divide by the coefficient of x.';hm='ആദ്യം സ്ഥിരസംഖ്യ കുറയ്ക്കുക, പിന്നെ x-ന്റെ ഗുണകം കൊണ്ട് ഹരിക്കുക.';s=[`${a}x = ${a*v+b} − ${b} = ${a*v}`,`x = ${a*v} / ${a} = ${v}`];break;
   case 'ap':c=n(5,15);v=a+(c-1)*b;q=`An AP starts with ${a} and has common difference ${b}. Find its ${c}th term.`;m=`ഒരു AP-യുടെ ആദ്യപദം ${a}, പൊതുവ്യത്യാസം ${b}. ${c}-ാം പദം കണ്ടെത്തുക.`;h='Use aₙ = a + (n − 1)d.';hm='aₙ = a + (n − 1)d ഉപയോഗിക്കുക.';s=['aₙ = a + (n − 1)d',`${a} + (${c} − 1) × ${b} = ${v}`];break;
   case 'geometry':v=a*b;q=`Find the area of a rectangle of length ${a} cm and width ${b} cm. Enter the number only.`;m=`നീളം ${a} cm, വീതി ${b} cm ആയ ദീർഘചതുരത്തിന്റെ വിസ്തീർണ്ണം എത്ര? സംഖ്യ മാത്രം നൽകുക.`;h='Area = length × width.';hm='വിസ്തീർണ്ണം = നീളം × വീതി.';s=[`Area = ${a} × ${b} = ${v} cm²`];break;
   case 'trigonometry':{const angles=[0,30,90],values=[0,.5,1],i=n(0,2);v=values[i];q=`Find sin(${angles[i]}°). Enter a decimal or fraction.`;m=`sin(${angles[i]}°) കണ്ടെത്തുക. ദശാംശമോ ഭിന്നസംഖ്യയോ നൽകാം.`;h='Use the standard sine values at 0°, 30° and 90°.';hm='0°, 30°, 90° എന്നിവയുടെ standard sine മൂല്യങ്ങൾ ഉപയോഗിക്കുക.';s=[`sin(${angles[i]}°) = ${v}`];break;}
   case 'differentiation':b=n(2,5);v=a*b;q=`For y = ${a}x^${b}, find dy/dx at x = 1.`;m=`y = ${a}x^${b} ആണെങ്കിൽ x = 1-ൽ dy/dx കണ്ടെത്തുക.`;h='Power rule: d(kxⁿ)/dx = knxⁿ⁻¹. Then set x = 1.';hm='Power rule: d(kxⁿ)/dx = knxⁿ⁻¹. ശേഷം x = 1 നൽകുക.';s=[`dy/dx = ${a} × ${b} × x^${b-1}`,`At x = 1: ${a*b} × 1^${b-1} = ${v}`];break;
   case 'integration':b=n(1,5);v=a*b*b/2;q=`Evaluate ∫ from 0 to ${b} of ${a}x dx.`;m=`∫₀^${b} ${a}x dx കണ്ടെത്തുക.`;h='Integrate kx to kx²/2, then subtract the lower-limit value.';hm='kx-ന്റെ integral kx²/2. മുകളിലെ limit മൂല്യത്തിൽ നിന്ന് താഴത്തെ limit മൂല്യം കുറയ്ക്കുക.';s=[`∫ ${a}x dx = ${a}x²/2 + C`,`[${a}x²/2] from 0 to ${b} = ${a} × ${b}²/2 − 0 = ${v}`];break;
   default:v=(a+b)*c;q=`Calculate (${a} + ${b}) × ${c}.`;m=`(${a} + ${b}) × ${c} കണക്കാക്കുക.`;h='Work out the bracket first.';hm='ആദ്യം bracket-ലെ കണക്കു ചെയ്യുക.';s=[`${a} + ${b} = ${a+b}`,`${a+b} × ${c} = ${v}`];
  }
  return {topic,q,ml:m,hint:h,hintMl:hm,steps:s,stepsMl:sm||s,answer:v,parameters:{a,b,c}};
 }
 return{make};
})();
if(typeof module!=='undefined')module.exports=PracticeMath;
