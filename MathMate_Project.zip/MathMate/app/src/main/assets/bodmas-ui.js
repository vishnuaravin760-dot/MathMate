'use strict';
let bodmasStage=0;
const bodmasExample=[
 ['6 + (8 − 3) × 2²', ['Start with the original expression. Press Next step to follow the map.','ആദ്യ കണക്ക് ഇതാണ്. Map പിന്തുടരാൻ അടുത്ത ഘട്ടം അമർത്തൂ.']],
 ['6 + 5 × 2²', ['B — Brackets: 8 − 3 = 5. Do the grouped part first.','B — Brackets: 8 − 3 = 5. Bracket-ലുള്ളത് ആദ്യം.']],
 ['6 + 5 × 4', ['O — Orders: 2² = 2 × 2 = 4. A square is not the same as multiplying by 2 in general.','O — Orders: 2² = 2 × 2 = 4. ഒരു സംഖ്യയുടെ square എന്നത് അതിനെ തന്നെ ഗുണിക്കുന്നതാണ്.']],
 ['6 + 20', ['D/M — Multiplication: 5 × 4 = 20. Do it before addition.','D/M — ഗുണനം: 5 × 4 = 20. കൂട്ടലിന് മുമ്പ് ചെയ്യണം.']],
 ['26', ['A/S — Addition: 6 + 20 = 26. All operations are now complete.','A/S — കൂട്ടൽ: 6 + 20 = 26. കണക്ക് പൂർത്തിയായി.']]
];
function renderBodmas(){$('bodmasExpression').textContent=bodmasExample[bodmasStage][0];$('bodmasReason').textContent=bodmasExample[bodmasStage][1][ml?1:0];$('bodmasBack').disabled=bodmasStage===0;$('bodmasNext').disabled=bodmasStage===4;document.querySelectorAll('[data-bodmas-tier]').forEach(e=>e.classList.toggle('active',Number(e.getAttribute('data-bodmas-tier'))===bodmasStage));}
$('openBodmas').onclick=()=>{showMode('learn');$('bodmasMap').open=true;$('bodmasMap').scrollIntoView({behavior:'smooth',block:'start'});};
$('bodmasNext').onclick=()=>{if(bodmasStage<4)bodmasStage++;renderBodmas();};$('bodmasBack').onclick=()=>{if(bodmasStage>0)bodmasStage--;renderBodmas();};$('bodmasReset').onclick=()=>{bodmasStage=0;renderBodmas();};
$('bodmasPractise').onclick=()=>{questReviewMode=false;$('questTopic').value='bodmas';$('questLevel').value='all';questRebuild();$('questCard').scrollIntoView({behavior:'smooth',block:'start'});};
const translateBeforeBodmas=translate;translate=function(){translateBeforeBodmas();renderBodmas();};renderBodmas();

$('bodmasAdvanced').onclick=()=>{questReviewMode=false;$('questTopic').value='advancedbodmas';$('questLevel').value='all';questRebuild();$('questCard').scrollIntoView({behavior:'smooth',block:'start'});};
