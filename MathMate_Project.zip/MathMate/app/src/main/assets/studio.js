
(()=>{
 const ids=id=>document.getElementById(id);
 const copy={formulas:['THE REFERENCE LIBRARY','Your formula book.','Find a rule. Understand it. Try it.','സൂത്രങ്ങളുടെ ശേഖരം','നിങ്ങളുടെ formula book.','സൂത്രങ്ങൾ കണ്ടെത്താം, ഉദാഹരണങ്ങളിലൂടെ പഠിക്കാം.'],history:['YOUR MATHS JOURNEY','Pick up where you left off.','Your recent questions, ready to revisit.','നിങ്ങളുടെ പഠനയാത്ര','നിർത്തിയിടത്തുനിന്ന് തുടരാം.','മുമ്പത്തെ ചോദ്യങ്ങൾ വീണ്ടും ചെയ്യാം.'],practice:['A LITTLE BETTER, EVERY DAY','Make it a daily win.','Choose a topic and put your skills to work.','ദിവസവും കുറച്ച് പരിശീലനം','ഇന്ന് ഒരു ചുവട് മുന്നോട്ട്.','വിഷയം തിരഞ്ഞെടുത്ത് പരിശീലിക്കാം.'],saved:['YOUR PERSONAL COLLECTION','Keep the good discoveries.','Your bookmarked answers in one place.','നിങ്ങളുടെ ശേഖരം','ഉപയോഗമുള്ള ഉത്തരങ്ങൾ സൂക്ഷിക്കാം.','സൂക്ഷിച്ച ഉത്തരങ്ങൾ ഇവിടെ കാണാം.'],learn:['THE LEARNING STUDIO','Small steps. Big progress.','Explore, practise, and reveal answers at your pace.','പഠനത്തിലേക്ക് സ്വാഗതം','ചെറിയ ചുവടുകൾ. വലിയ പുരോഗതി.','സ്വന്തം വേഗത്തിൽ പഠിക്കാം, പരിശീലിക്കാം.']};
 for(const [mode,c] of Object.entries(copy)){const panel=ids(mode+'Panel');if(!panel)continue;const h=document.createElement('div');h.className='screen-heading';h.innerHTML='<small></small><h1></h1><p></p>';panel.prepend(h);}
 const tool=document.createElement('div');tool.className='studio-toolbar';tool.innerHTML='<span data-en="YOUR SOLVING STUDIO" data-ml="നിങ്ങളുടെ Solve Studio">YOUR SOLVING STUDIO</span><button type="button" id="studioNew" data-en="＋ New question" data-ml="＋ പുതിയ ചോദ്യം">＋ New question</button>';ids('solvePanel').prepend(tool);
 ids('studioNew').onclick=()=>{if(ids('question').disabled)return;ids('removePhoto').click();ids('question').value='';ids('question').dispatchEvent(new Event('input'));resetResult();ids('question').focus();};
 const step=document.createElement('div');step.className='studio-step';step.dataset.en='02 / REVIEW YOUR QUESTION';step.dataset.ml='02 / ചോദ്യം പരിശോധിക്കൂ';ids('question').before(step);
 const solveStep=document.createElement('div');solveStep.className='studio-step';solveStep.dataset.en='03 / CHOOSE YOUR SOLUTION';solveStep.dataset.ml='03 / ഉത്തരം കണ്ടെത്താം';document.querySelector('.solve-actions').before(solveStep);
 const read=ids('readMathPhoto');read.dataset.en='⌕  Read with AI →';read.dataset.ml='⌕  AI ഉപയോഗിച്ച് വായിക്കൂ →';
 const ai=ids('aiButton');ai.dataset.en='✦  Solve with AI →';ai.dataset.ml='✦  AI ഉപയോഗിച്ച് പരിഹരിക്കൂ →';
 ids('solveButton').dataset.en='⚡ Quick solve · Offline';ids('solveButton').dataset.ml='⚡ വേഗത്തിൽ പരിഹരിക്കൂ · Offline';
 document.querySelector('.app-version').textContent='5.0';
 function refresh(){const ml=document.documentElement.lang==='ml';for(const [mode,c] of Object.entries(copy)){const h=ids(mode+'Panel')?.querySelector('.screen-heading');if(!h)continue;const start=ml?3:0;h.children[0].textContent=c[start];h.children[1].textContent=c[start+1];h.children[2].textContent=c[start+2];}for(const el of [read,ai,ids('solveButton'),tool.children[0],ids('studioNew'),step,solveStep])el.textContent=ml?el.dataset.ml:el.dataset.en;}
 refresh();new MutationObserver(refresh).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
 // Search collections without changing or deleting stored answers.
 for(const [panelId,listId,selector] of [['historyPanel','historyList','.history-item'],['savedPanel','bookmarkList','.saved-card']]){
   const panel=ids(panelId),list=ids(listId);if(!panel||!list)continue;
   const input=document.createElement('input');input.type='search';input.className='studio-search';input.placeholder='Search your questions…';input.setAttribute('aria-label','Search questions');panel.querySelector('.screen-heading').after(input);
   const empty=document.createElement('p');empty.className='studio-empty';empty.hidden=true;empty.textContent='No matching questions.';list.after(empty);
   function filter(){const q=input.value.toLowerCase().trim(),items=[...list.querySelectorAll(selector)];for(const item of items)item.hidden=!!q&&!item.textContent.toLowerCase().includes(q);empty.hidden=!q||items.some(el=>!el.hidden);}
   input.addEventListener('input',filter);new MutationObserver(filter).observe(list,{childList:true});
 }
 // Show progress on the two independent operations, including Android callbacks.
 function busyLabels(){read.textContent=read.disabled?(document.documentElement.lang==='ml'?'വായിക്കുന്നു…':'Reading photo…'):(document.documentElement.lang==='ml'?read.dataset.ml:read.dataset.en);ai.textContent=aiWorking&&!photoFlow.pending?(document.documentElement.lang==='ml'?'പരിഹരിക്കുന്നു…':'Solving with AI…'):(document.documentElement.lang==='ml'?ai.dataset.ml:ai.dataset.en);read.setAttribute('aria-busy',String(photoFlow.pending));ai.setAttribute('aria-busy',String(aiWorking&&!photoFlow.pending));}
 new MutationObserver(busyLabels).observe(ai,{attributes:true,attributeFilter:['disabled']});new MutationObserver(busyLabels).observe(read,{attributes:true,attributeFilter:['disabled']});
})();
