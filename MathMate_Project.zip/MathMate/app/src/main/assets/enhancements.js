'use strict';
// All rendering assets, practice questions and bookmarks work without a network.
const topicBank={
 catalog:{en:'Formula book',ml:'Formulas',example:'(2 + 3)^2',latex:'(a+b)^2=a^2+2ab+b^2'},
 powers:{en:'Square / Cube / Root',ml:'Square / Cube / Root',example:'12',latex:'n^2=n\\times n,\\quad n^3=n\\times n\\times n'},
 arithmetic:{en:'Arithmetic',ml:'കണക്കുകൾ',example:'(125 + 75) / 4',latex:'\\frac{125+75}{4}'},
 ap:{en:'Progressions',ml:'AP',example:'An AP is 2, 5, 8, 11, ... Find the 20th term and the sum of the first 20 terms.',latex:'a_n=a+(n-1)d,\\quad S_n=\\frac{n}{2}[2a+(n-1)d]'},
 algebra:{en:'Algebra',ml:'Algebra',example:'x^2 - 5x + 6 = 0',latex:'x=\\frac{-b\\pm\\sqrt{b^2-4ac}}{2a}'},
 geometry:{en:'Geometry',ml:'Geometry',example:'A right triangle has perpendicular sides 6 cm and 8 cm. Find its hypotenuse and area.',latex:'c=\\sqrt{a^2+b^2},\\quad A=\\frac12 bh'},
 trigonometry:{en:'Trigonometry',ml:'Trigonometry',example:'Find sin(30) + cos(60). Use degrees.',latex:'\\sin^2\\theta+\\cos^2\\theta=1'},
 differentiation:{en:'Differentiation',ml:'Differentiation',example:'Differentiate x^3 * sin(x) with respect to x. Use radians.',latex:'\\frac{d}{dx}(uv)=u\\frac{dv}{dx}+v\\frac{du}{dx}'},
 integration:{en:'Integration',ml:'Integration',example:'Integrate x^2 * e^x with respect to x. Explain using integration by parts.',latex:'\\int u\\,dv=uv-\\int v\\,du'}
};
let currentTopic='arithmetic',currentRecord=null,bookmarks=[],practice=null,practiceShown=false,practiceScore=0,practiceAttempts=0,practiceCounted=false;
try{const values=JSON.parse(localStorage.getItem('mathmate-bookmarks')||'[]');if(Array.isArray(values))bookmarks=values.filter(b=>b&&typeof b.q==='string'&&typeof b.answer==='string').slice(0,100);}catch(e){}
function drawMath(el){if(typeof window.renderMathInElement==='function')try{window.renderMathInElement(el,{delimiters:[{left:'$$',right:'$$',display:true},{left:'\\[',right:'\\]',display:true},{left:'\\(',right:'\\)',display:false},{left:'$',right:'$',display:false}],throwOnError:false,trust:false,maxSize:6,maxExpand:500,strict:'ignore'});}catch(e){}}
function renderTopic(){
 $('topics').replaceChildren();Object.entries(topicBank).forEach(([key,t])=>{const b=document.createElement('button');b.type='button';b.textContent=t[ml?'ml':'en'];const symbol=document.createElement('span');symbol.className='topic-symbol';symbol.textContent={arithmetic:'＋',ap:'∑',algebra:'x²',geometry:'△',trigonometry:'sin θ',differentiation:'d/dx',integration:'∫',powers:'n² / n³',catalog:'ƒ'}[key];symbol.setAttribute('aria-hidden','true');b.prepend(symbol);b.className='topic-chip'+(key===currentTopic?' selected':'');b.setAttribute('aria-pressed',key===currentTopic?'true':'false');b.onclick=()=>{currentTopic=key;renderTopic();if(key==='powers'){showMode('formulas');$('powersCard').scrollIntoView({behavior:'smooth',block:'start'});}else if(key==='catalog'){openFormulaLibrary();}};$('topics').append(b);});
 const hint=currentTopic==='arithmetic'||currentTopic==='algebra'||currentTopic==='powers'?tr('Use Offline Solve for supported calculations, or AI Solve.','പിന്തുണയ്ക്കുന്ന കണക്കുകൾക്ക് Offline Solve അല്ലെങ്കിൽ AI Solve ഉപയോഗിക്കുക.'):tr('Use AI Solve for this topic. Practice questions are available offline.','ഈ വിഷയത്തിന് AI Solve ഉപയോഗിക്കുക. Practice ചോദ്യങ്ങൾ offline ലഭ്യമാണ്.');
 $('topicHint').textContent=hint;$('topicFormula').textContent='\\['+topicBank[currentTopic].latex+'\\]';drawMath($('topicFormula'));
}
$('topicExample').onclick=()=>{$('question').value=topicBank[currentTopic].example;resetResult();$('question').focus();};
const originalResult=showResult;
showResult=function(r){originalResult(r);currentRecord={q:$('question').value.trim()||tr('[Photo question]','[Photo ചോദ്യം]'),answer:r.answer,steps:r.steps||[],note:r.note||'',ai:false};$('resultActions').hidden=false;$('explainPanel').hidden=true;drawMath($('answer'));drawMath($('steps'));updateBookmarkButton();};
const originalAI=showAI;
showAI=function(answer,incomplete){originalAI(answer,incomplete);if(currentRecord)currentRecord.ai=true;};
function updateBookmarkButton(){const saved=currentRecord&&bookmarks.some(b=>b.q===currentRecord.q&&b.answer===currentRecord.answer);$('bookmarkButton').textContent=saved?tr('★ Saved','★ സൂക്ഷിച്ചു'):tr('☆ Save question','☆ ചോദ്യം സൂക്ഷിക്കുക');}
$('bookmarkButton').onclick=()=>{
 if(!currentRecord)return;const i=bookmarks.findIndex(b=>b.q===currentRecord.q&&b.answer===currentRecord.answer);
 if(i>=0)bookmarks.splice(i,1);else{if(bookmarks.length>=100){error(new Error(tr('100 bookmarks saved. Remove one before adding another.','100 bookmarks ഉണ്ട്. പുതിയത് ചേർക്കാൻ ഒന്ന് നീക്കുക.')));return;}bookmarks.unshift({...currentRecord,q:currentRecord.q||tr('[Photo question]','[Photo ചോദ്യം]'),savedAt:Date.now()});}
 try{localStorage.setItem('mathmate-bookmarks',JSON.stringify(bookmarks));}catch(e){$('libraryStatus').textContent=tr('Storage is full. New bookmarks may not persist.','Storage നിറഞ്ഞു; പുതിയ bookmarks സൂക്ഷിക്കാനായേക്കില്ല.');}
 updateBookmarkButton();renderBookmarks();
};
function renderBookmarks(){
 const host=$('bookmarkList');host.replaceChildren();if(!bookmarks.length){const p=document.createElement('p');p.className='muted';p.textContent=tr('No saved questions yet. Use ☆ Save question below an answer.','ഉത്തരത്തിന് താഴെയുള്ള ☆ ഉപയോഗിച്ച് ചോദ്യങ്ങൾ സൂക്ഷിക്കാം.');host.append(p);}
 bookmarks.forEach((record,i)=>{const card=document.createElement('div');card.className='saved-card';const open=document.createElement('button');open.className='saved-open';open.textContent=record.q.slice(0,160)+(record.q.length>160?'…':'');const small=document.createElement('small');small.textContent=(record.ai?'AI · ':'Offline · ')+record.answer.slice(0,100);open.append(small);open.onclick=()=>{showMode('solve');$('question').value=record.q;if(record.ai)showAI(record.answer,false);else showResult({answer:record.answer,steps:Array.isArray(record.steps)?record.steps:[],note:record.note||''});currentRecord={...record};updateBookmarkButton();};const remove=document.createElement('button');remove.className='text-button';remove.textContent=tr('Remove','നീക്കുക');remove.onclick=()=>{bookmarks.splice(i,1);try{localStorage.setItem('mathmate-bookmarks',JSON.stringify(bookmarks));}catch(e){}renderBookmarks();updateBookmarkButton();};card.append(open,remove);host.append(card);});
}
$('explainButton').onclick=()=>{if(!currentRecord)return;$('explainPanel').hidden=!$('explainPanel').hidden;if(!$('explainPanel').hidden)$('explainText').focus();};
$('askStep').onclick=()=>{
 if(!currentRecord||scanning||aiWorking)return;const detail=$('explainText').value.trim();
 if(!detail){$('explainStatus').textContent=tr('Type a step number or paste the line you want explained.','മനസ്സിലാകാത്ത step number അല്ലെങ്കിൽ വരി നൽകുക.');return;}
 if(!window.PhotoReader||typeof window.PhotoReader.solveAI!=='function'){error(new Error('Install the Android app to ask AI.'));return;}
 aiQuestion='Original maths question:\n'+currentRecord.q.slice(0,700)+'\nPrevious answer (may be shortened):\n'+currentRecord.answer.slice(0,2300)+'\nExplain this part in smaller, simpler teaching steps: '+detail.slice(0,300)+'\nIf the previous calculation is wrong, correct it. Do not invent omitted steps.';
 aiWorking=true;controls();$('aiStatus').hidden=false;$('aiStatus').textContent=tr('AI is explaining the step…','AI ഈ ഘട്ടം വിശദീകരിക്കുന്നു…');
 try{window.PhotoReader.solveAI(aiQuestion,ml?'ml':'en',false);}catch(e){window.receiveAI(null,'Could not start AI.',false);}
};
const oldReset=resetResult;resetResult=function(){oldReset();$('resultActions').hidden=true;$('explainPanel').hidden=true;};
const oldMode=showMode;showMode=function(next){mode=next;['solve','formulas','history','practice','saved'].forEach(m=>$(m+'Panel').hidden=m!==next);document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===next));resetResult();renderHistory();if(next==='saved')renderBookmarks();if(next==='practice'&&!practice)newPractice();};
const oldControls=controls;controls=function(){oldControls();const busy=scanning||aiWorking;for(const id of ['editPhoto','askStep','topicExample','bookmarkButton','explainText'])$(id).disabled=busy;};
$('editPhoto').onclick=()=>{if(window.PhotoReader&&typeof window.PhotoReader.editPhoto==='function')window.PhotoReader.editPhoto();else error(new Error('Photo editing requires the updated Android app.'));};
window.photoEditingStarted=function(){photoBusy(true);$('scanStatus').hidden=false;$('scanStatus').textContent=tr('Edit your photo, then tap Use photo.','Photo edit ചെയ്ത് Use photo അമർത്തുക.');};
window.photoEditingFinished=function(){photoBusy(false);$('scanStatus').hidden=true;};
function insertKey(text,move=0){const q=$('question'),a=q.selectionStart??q.value.length,b=q.selectionEnd??a;q.value=q.value.slice(0,a)+text+q.value.slice(b);const pos=a+text.length+move;q.focus();q.setSelectionRange(pos,pos);resetResult();}
const keys=[['÷',' / '],['×',' * '],['−','-'],['+','+'],['=','='],['x','x'],['y','y'],['x²','^2'],['xⁿ','^'],['√','sqrt()',-1],['a/b','()/()',-4],['π','pi'],['(', '('],[')',')'],['sin','sin()',-1],['cos','cos()',-1],['∫','Integrate  with respect to x',-18],['d/dx','Differentiate  with respect to x',-18],['%','%'],['⌫',null]];
keys.forEach(([label,text,move])=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.className='math-key';b.setAttribute('aria-label',label==='⌫'?'Delete previous character':label);b.onmousedown=e=>e.preventDefault();b.onclick=()=>{if(scanning||aiWorking)return;if(text!==null)insertKey(text,move||0);else{const q=$('question'),a=q.selectionStart??q.value.length,end=q.selectionEnd??a;const begin=a===end?Math.max(0,a-1):a;q.value=q.value.slice(0,begin)+q.value.slice(end);q.focus();q.setSelectionRange(begin,begin);resetResult();}};$('mathKeys').append(b);});
$('keyboardToggle').onclick=()=>{$('mathKeys').hidden=!$('mathKeys').hidden;$('keyboardToggle').setAttribute('aria-expanded',String(!$('mathKeys').hidden));};
function renderPractice(){
 if(!practice)return;$('practiceQuestion').textContent=ml?practice.ml:practice.q;$('practiceHint').textContent=ml?practice.hintMl:practice.hint;
 $('practiceSolution').textContent=(ml?practice.stepsMl:practice.steps).join('\n');
 $('practiceScore').textContent=tr(`Correct first attempts: ${practiceScore} / ${practiceAttempts}`,`ആദ്യ ശ്രമത്തിൽ ശരി: ${practiceScore} / ${practiceAttempts}`);
 drawMath($('practiceQuestion'));
}
function newPractice(){practice=PracticeMath.make($('practiceTopic').value);practiceShown=false;practiceCounted=false;$('practiceAnswer').value='';$('practiceFeedback').textContent='';$('practiceHint').hidden=true;$('practiceSolution').hidden=true;renderPractice();}
$('newPractice').onclick=newPractice;$('practiceTopic').onchange=newPractice;
$('hintPractice').onclick=()=>{if(!practice)newPractice();$('practiceHint').hidden=false;};
$('solutionPractice').onclick=()=>{if(!practice)newPractice();if(!practiceCounted){practiceCounted=true;practiceAttempts++;}practiceShown=true;$('practiceSolution').hidden=false;renderPractice();};
$('checkPractice').onclick=()=>{
 if(!practice)newPractice();try{
  const input=$('practiceAnswer').value.trim();if(!input)throw Error(tr('Enter your answer first.','ആദ്യം ഉത്തരം നൽകുക.'));
  const value=MathMate.calc(MathMate.parse(input));const right=Math.abs(value-practice.answer)<=1e-8*Math.max(1,Math.abs(practice.answer));
  if(!practiceCounted){practiceCounted=true;practiceAttempts++;if(right&&!practiceShown)practiceScore++;}
  $('practiceFeedback').textContent=right?tr('✓ Correct! Try the next question.','✓ ശരിയാണ്! അടുത്ത ചോദ്യം ചെയ്യാം.'):tr('Try again. Use Hint or Show solution if needed.','വീണ്ടും ശ്രമിക്കൂ. Hint അല്ലെങ്കിൽ Show solution ഉപയോഗിക്കാം.');renderPractice();
 }catch(e){$('practiceFeedback').textContent=e.message;}
};
const originalTranslate=translate;translate=function(){originalTranslate();renderTopic();renderBookmarks();renderPractice();updateBookmarkButton();};
renderTopic();renderBookmarks();

// Dedicated exact Square/Cube tool and bounded range table; no AI request.
let selectedPower='square';
function runPower(operation){
 selectedPower=operation;$('powerError').hidden=true;$('powerResults').hidden=true;
 for(const [key,id] of [['square','calculatePowers'],['cube','calculateCube'],['root','calculateRoot']]){$(id).setAttribute('aria-pressed',String(key===operation));$(key+'Card').hidden=key!==operation;}
 try{
  let step;
  if(operation==='root'){const r=ExactPowers.squareRoot($('powerNumber').value);$('rootAnswer').textContent=(r.exact?'':'≈ ')+r.root;step='√'+r.number+(r.exact?' = ':' ≈ ')+r.root;if(!r.exact)step+='\n'+tr('Approximate decimal value.','ഏകദേശ ദശാംശ മൂല്യം.');}
  else{const r=ExactPowers.calculate($('powerNumber').value),n=r.number.startsWith('-')?'('+r.number+')':r.number;if(operation==='square'){$('squareAnswer').textContent=r.square;step=n+' × '+n+' = '+r.square;}else{$('cubeAnswer').textContent=r.cube;step=n+' × '+n+' × '+n+' = '+r.cube;}}
  $('powerSteps').textContent=step;$('powerResults').hidden=false;
 }catch(e){$('powerError').textContent=(ml?'സംഖ്യ പരിശോധിക്കൂ: ':'')+e.message;$('powerError').hidden=false;}
}
$('calculatePowers').onclick=()=>runPower('square');$('calculateCube').onclick=()=>runPower('cube');$('calculateRoot').onclick=()=>runPower('root');
$('powerNumber').oninput=()=>{$('powerResults').hidden=true;$('powerError').hidden=true;};
$('powerNumber').onkeydown=e=>{if(e.key==='Enter')runPower(selectedPower);};
$('showPowerTable').onclick=()=>{
 $('powerTableError').hidden=true;$('powerTableWrap').hidden=true;$('powerTableBody').replaceChildren();
 try{const rows=ExactPowers.table($('powerFrom').value,$('powerTo').value);for(const row of rows){const tr=document.createElement('tr');for(const key of ['number','square','cube']){const cell=document.createElement('td');cell.textContent=row[key];tr.append(cell);}$('powerTableBody').append(tr);}$('powerTableCaption').textContent=rows[0].number+' → '+rows[rows.length-1].number+' · '+rows.length+tr(' rows',' വരികൾ');$('powerTableWrap').hidden=false;}
 catch(e){$('powerTableError').textContent=(ml?'പരിധി പരിശോധിക്കൂ: ':'')+e.message;$('powerTableError').hidden=false;}
};
for(const id of ['powerFrom','powerTo'])$(id).oninput=()=>{$('powerTableWrap').hidden=true;$('powerTableError').hidden=true;};

function renderFormulaLibrary(){
 const selected=$('formulaCategory').value||'algebra',query=$('formulaSearch').value||'',rows=FormulaBook.search(query,selected);
 $('formulaBookList').replaceChildren();$('formulaCount').textContent=rows.length+tr(' formulas',' സൂത്രവാക്യങ്ങൾ');
 for(const f of rows){const card=document.createElement('article');card.className='formula-entry';const heading=document.createElement('div');heading.className='formula-entry-heading';const title=document.createElement('h3');title.textContent=ml?f.ml:f.title;const explain=document.createElement('button');explain.type='button';explain.textContent=tr('Explain','വിശദീകരണം');explain.onclick=()=>{showMode('solve');$('question').value=tr('Explain this maths formula, define its variables and conditions, and show one worked example: ','ഈ സൂത്രവാക്യം, അതിലെ അക്ഷരങ്ങൾ, നിബന്ധനകൾ എന്നിവ വിശദീകരിച്ച് ഒരു ഉദാഹരണം നൽകുക: ')+f.tex+(f.note?'\nConditions: '+f.note:'');$('question').focus();};heading.append(title,explain);const eq=document.createElement('div');eq.className='formula-equation';eq.textContent='\\['+f.tex+'\\]';card.append(heading,eq);if(f.note){const note=document.createElement('p');note.className='hint';note.textContent=ml?f.noteMl:f.note;card.append(note);}$('formulaBookList').append(card);drawMath(eq);}
 if(!rows.length){const p=document.createElement('p');p.className='hint';p.textContent=tr('No matching formula. Try a shorter word or choose All topics.','ചേരുന്ന formula ഇല്ല. ചെറിയ വാക്ക് നൽകൂ അല്ലെങ്കിൽ All topics തിരഞ്ഞെടുക്കൂ.');$('formulaBookList').append(p);}
}
function formulaBookLabels(){const selected=$('formulaCategory').value||'algebra';$('formulaCategory').replaceChildren();const entries=[['all',tr('All topics','എല്ലാ വിഷയങ്ങളും')],...Object.entries(FormulaBook.categories).map(([key,names])=>[key,names[ml?1:0]])];for(const [value,label]of entries){const option=document.createElement('option');option.value=value;option.textContent=label;$('formulaCategory').append(option);}$('formulaCategory').value=selected;$('formulaBookTotal').textContent=FormulaBook.items.length+tr(' formulas · 8 topics · offline',' formulas · 8 വിഷയങ്ങൾ · offline');}
function openFormulaLibrary(){showMode('formulas');$('formulaLibrary').open=true;renderFormulaLibrary();$('formulaLibrary').scrollIntoView({behavior:'smooth',block:'start'});}
$('openFormulaBook').onclick=openFormulaLibrary;$('openNumberTools').onclick=()=>{$('formulaLibrary').open=false;$('powersCard').scrollIntoView({behavior:'smooth',block:'start'});};
$('formulaCategory').onchange=renderFormulaLibrary;$('formulaSearch').oninput=()=>{if($('formulaSearch').value.trim())$('formulaCategory').value='all';renderFormulaLibrary();};$('formulaLibrary').ontoggle=()=>{if($('formulaLibrary').open)renderFormulaLibrary();};
const translateBeforeFormulaBook=translate;translate=function(){translateBeforeFormulaBook();formulaBookLabels();if($('formulaLibrary').open)renderFormulaLibrary();};
formulaBookLabels();
