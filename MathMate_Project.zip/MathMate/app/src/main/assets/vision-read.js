/* Explicit user action sends the retained photo to the existing AI connection. */
let readingMathPhoto=false;
const visionButton=document.createElement('button');visionButton.id='readMathPhoto';visionButton.type='button';visionButton.className='primary';visionButton.hidden=true;visionButton.textContent='Read maths with AI →';
const visionHelp=document.createElement('p');visionHelp.className='hint';visionHelp.hidden=true;visionHelp.textContent='Sends this photo to your configured AI service. Uses internet and one AI request. Check the reading before Quick Solve.';
$('question').before(visionButton,visionHelp);
const beforeVisionPhotoState=window.setPhotoState;
window.setPhotoState=function(available){beforeVisionPhotoState(available);visionButton.hidden=!available;visionHelp.hidden=!available;};
const beforeVisionAI=window.receiveAI;
window.receiveAI=function(answer,message,incomplete){
 if(!readingMathPhoto){beforeVisionAI(answer,message,incomplete);return;}
 readingMathPhoto=false;aiWorking=false;controls();visionButton.disabled=false;$('aiStatus').hidden=true;
 if(message){error(new Error(message));return;}
 try{
  if(incomplete)throw Error('Photo reading was cut short. Try cropping to one question.');
  const result=PhotoMath.readTranscription(answer);
  if(!result.expression)throw Error(result.note||'Some symbols are unclear. Crop or retake the photo.');
  $('question').value=MathMate.normalize(result.expression);resetResult();updatePhotoReview(true);
  $('scanStatus').hidden=false;$('scanStatus').textContent=tr('AI read the photo. Compare with the original, then tap Quick solve. Nothing has been solved automatically.','AI photo വായിച്ചു. Original-ുമായി പരിശോധിച്ചശേഷം Quick solve അമർത്തൂ.');
  $('question').scrollIntoView({behavior:'smooth',block:'center'});
 }catch(e){error(e);}
};
visionButton.onclick=()=>{
 if(scanning||aiWorking)return;
 if(!window.PhotoReader||typeof window.PhotoReader.solveAI!=='function'){error(new Error('Photo AI works in the installed Android app.'));return;}
 resetResult();readingMathPhoto=true;aiWorking=true;controls();visionButton.disabled=true;$('aiStatus').hidden=false;$('aiStatus').textContent=tr('Reading maths from the original photo…','Original photo-യിൽ നിന്ന് maths വായിക്കുന്നു…');
 const prompt='Transcribe the maths question from the ATTACHED IMAGE only. Ignore the app OCR text. Do not solve, simplify, or compute it. Return one JSON object: {"expression":"exact question in calculator notation","uncertain":false,"note":""}. Preserve ALL parentheses, superscripts and fractions: use ^ for exponents, / with parentheses for a fraction, sqrt(...) for roots, = for equations, and a newline for two equations. A superscript zero means ^0, not degrees. Do not invent a missing sign or denominator. If any symbol is unclear, return {"expression":"","uncertain":true,"note":"which part is unclear"}. Do not guess. Do not include teaching steps or the answer.';
 try{window.PhotoReader.solveAI(prompt,'en',true);}catch(e){window.receiveAI(null,'Could not start photo AI. Check AI Settings.',false);}
};
