function photoExpressionTex(q){
 function tex(n){if(n.k==='n')return String(n.v);if(n.k==='x'||n.k==='y')return n.k;if(n.k==='neg')return '-'+tex(n.a);if(n.k==='fn')return n.f==='sqrt'?'\\sqrt{'+tex(n.a)+'}':'\\operatorname{'+n.f+'}\\left('+tex(n.a)+'\\right)';const a=tex(n.a),b=tex(n.b);if(n.k==='/')return '\\frac{'+a+'}{'+b+'}';if(n.k==='^')return '{\\left('+a+'\\right)}^{'+b+'}';return '\\left('+a+(n.k==='*'?'\\times ':n.k)+b+'\\right)';}
 return q.split(/\n|;/).map(row=>row.split('=').map(side=>tex(MathMate.parse(side))).join('=')).join('\\quad ');
}
/* Photo v2: one explicit request, adjacent status, reviewed expression, confirmation. */
const photoFlow={available:false,request:0,pending:false,confirmed:'',raw:''};
const flow=document.createElement('section');flow.id='mathPhotoFlow';flow.hidden=true;
flow.innerHTML='<div class="photo-flow-head">PHOTO → READ → CHECK → SOLVE <span>v2</span></div><img id="mathPhotoPreview" alt="Selected maths photo"><p class="hint">Check that this photo contains the entire question, including powers and the denominator.</p><button id="readOfflinePhoto" type="button" class="primary" data-en="⚡ Read photo offline →" data-ml="⚡ Internet ഇല്ലാതെ വായിക്കൂ →">⚡ Read photo offline →</button><p class="hint" data-en="Free · On this phone · No AI quota. Best for clear printed text. Check handwriting, powers and fractions carefully." data-ml="സൗജന്യം · ഫോണിൽ തന്നെ · AI quota വേണ്ട. കൈയെഴുത്ത്, powers, fractions പരിശോധിച്ച് തിരുത്തുക.">Free · On this phone · No AI quota. Best for clear printed text. Check handwriting, powers and fractions carefully.</p><p id="offlineReadStatus" role="status" aria-live="polite"></p><button id="readMathPhoto" type="button" class="primary">Read maths with AI →</button><p class="hint">Sends this selected photo to your configured AI service. Internet and AI quota required.</p><p id="photoFlowStatus" role="status" aria-live="polite"></p><button id="photoRetry" type="button" hidden>Retry photo reading</button><details id="rawOCRDetails" hidden><summary>Offline text draft (may be incorrect)</summary><pre id="rawOCRText"></pre><button id="useOCRDraft" type="button">Use this draft and edit it</button></details>';
$('question').before(flow);
const review=document.createElement('section');review.id='mathReviewV2';review.hidden=true;
review.innerHTML='<b>Check the maths question</b><div id="mathExpressionPreview"></div><p class="hint">Compare with the photo. Edit the input above if a power, sign or fraction is wrong.</p><button id="confirmMathReading" type="button">✓ This matches my question</button><p id="mathConfirmStatus" role="status"></p>';
$('question').after(review);
$('question').after($('error')); // Errors remain next to the question, not below all topic tiles.
function photoStatus(message,bad=false){$('photoFlowStatus').textContent=message;$('photoFlowStatus').className=bad?'photo-flow-error':'photo-flow-status';}
function paintReview(){
 if(!photoFlow.available)return;
 review.hidden=false;const q=$('question').value.trim();
 const host=$('mathExpressionPreview');host.textContent=q||'No question read yet.';
 try{if(q&&window.katex)window.katex.render(photoExpressionTex(q),host,{throwOnError:false,displayMode:true});}catch(e){}
 $('mathConfirmStatus').textContent=photoFlow.confirmed===q&&q?'Confirmed. You can now solve.':'Not confirmed yet.';
 $('confirmMathReading').disabled=!q||photoFlow.pending;
}
const oldSetPhotoState=window.setPhotoState;
window.setPhotoState=function(available){oldSetPhotoState(available);photoFlow.available=available;flow.hidden=!available;review.hidden=!available;if(!available){photoFlow.raw='';$('offlineReadStatus').textContent='';photoFlow.confirmed='';$('mathPhotoPreview').removeAttribute('src');} };
window.setMathPhotoPreview=function(data){
 photoFlow.request++;photoFlow.pending=false;photoFlow.confirmed='';
 if(data){photoFlow.raw='';$('offlineReadStatus').textContent=tr('Preparing offline text on this phone…','ഫോണിൽ offline text തയ്യാറാക്കുന്നു…');$('mathPhotoPreview').src=data;$('question').value='';$('rawOCRDetails').hidden=true;$('photoRetry').hidden=true;photoStatus('Photo ready. Choose Offline Read or Read with AI, then check the text.');}
 paintReview();
};
window.receiveOCR=function(text,message){
 photoBusy(false);resetResult();
 if(message){if(message!=='Cancelled'){$('offlineReadStatus').textContent=tr('Offline reader could not find clear text. Retake/crop the photo, type the question, or try AI.','Offline വായനയിൽ വ്യക്തമായ text കിട്ടിയില്ല. Photo crop ചെയ്യുക, ചോദ്യം എഴുതുക, അല്ലെങ്കിൽ AI ഉപയോഗിക്കുക.');}return;}
 photoFlow.raw=String(text||'');$('rawOCRText').textContent=photoFlow.raw;$('rawOCRDetails').hidden=!photoFlow.raw;
 $('offlineReadStatus').textContent=photoFlow.raw?tr('Offline text ready. Tap Read photo offline.','Offline text തയ്യാറായി. Offline Read അമർത്തുക.'):tr('No offline text found. Type the question or try AI.','Offline text കിട്ടിയില്ല. ചോദ്യം എഴുതുക അല്ലെങ്കിൽ AI ഉപയോഗിക്കുക.');$('scanStatus').hidden=true;paintReview();
};
window.receiveOCRLayout=function(lines){try{window.receiveOCR(PhotoMath.reconstruct(lines).text,null);}catch(e){window.receiveOCR(lines.map(l=>l.text).join('\n'),null);}};
function useOfflinePhoto(){
 if(photoFlow.pending||aiWorking){$('offlineReadStatus').textContent=tr('Wait for the current AI request to finish, then use Offline Read.','AI request കഴിയുമ്പോൾ Offline Read ഉപയോഗിക്കുക.');return;}
 if(!photoFlow.raw.trim()){$('offlineReadStatus').textContent=tr('No readable offline text yet. Try a clearer crop or type the question below.','Offline text ലഭിച്ചിട്ടില്ല. വ്യക്തമായ photo crop ചെയ്യുക അല്ലെങ്കിൽ താഴെ ചോദ്യം എഴുതുക.');return;}
 resetResult();$('question').value=MathMate.normalize(photoFlow.raw);photoFlow.confirmed='';paintReview();
 photoStatus(tr('Offline draft loaded. Edit any mistakes, confirm the question, then use Quick solve · Offline.','Offline ചോദ്യം ചേർത്തു. തെറ്റുകൾ തിരുത്തി confirm ചെയ്തശേഷം Quick solve · Offline അമർത്തുക.'));
 $('offlineReadStatus').textContent=tr('Read on this phone. No AI request was sent. If the photo includes answer choices, keep only the question in the box.','ഫോണിൽ തന്നെ വായിച്ചു. AI request അയച്ചിട്ടില്ല. Answer options ഉണ്ടെങ്കിൽ box-ൽ ചോദ്യം മാത്രം വയ്ക്കുക.');
 $('question').scrollIntoView({behavior:'smooth',block:'center'});
}
$('readOfflinePhoto').onclick=$('useOCRDraft').onclick=useOfflinePhoto;
$('question').addEventListener('input',()=>{photoFlow.confirmed='';paintReview();});
$('confirmMathReading').onclick=()=>{photoFlow.confirmed=$('question').value.trim();paintReview();};
let readingTimer;
function finishReading(){photoFlow.pending=false;aiWorking=false;controls();$('readMathPhoto').disabled=false;clearTimeout(readingTimer);paintReview();}
window.receivePhotoReading=function(id,expression,uncertain,note,message){
 if(String(photoFlow.request)!==id)return;
 finishReading();$('photoRetry').hidden=false;
 if(message){photoStatus(message,true);return;}
 if(uncertain||!expression){photoStatus(note||'The symbols are unclear. Crop or retake the photo, then retry.',true);return;}
 const q=MathMate.normalize(expression);
 if(q.length>600){photoStatus('The question is too long. Crop to one question.',true);return;}
 $('question').value=q;photoFlow.confirmed='';paintReview();
 photoStatus('Photo read. Check the question below, then confirm it before solving.');
};
$('readMathPhoto').onclick=$('photoRetry').onclick=()=>{
 if(scanning||aiWorking||photoFlow.pending)return;
 if(!window.PhotoReader||typeof window.PhotoReader.readMathPhoto!=='function'){photoStatus('Install the matching MathMate photo v2 APK. This app and Worker must be updated together.',true);return;}
 resetResult();photoFlow.pending=true;photoFlow.confirmed='';photoFlow.request++;aiWorking=true;controls();$('readMathPhoto').disabled=true;$('photoRetry').hidden=true;
 photoStatus('Reading the original photo… This can take up to a minute.');
 const id=String(photoFlow.request);
 readingTimer=setTimeout(()=>{if(photoFlow.pending&&id===String(photoFlow.request)){photoFlow.request++;finishReading();photoStatus('The photo request timed out. Wait a moment, then retry.',true);$('photoRetry').hidden=false;}},80000);
 try{window.PhotoReader.readMathPhoto(id);}catch(e){window.receivePhotoReading(id,'',true,'','Could not start photo reading. Please reopen the app.');}
};
const originalQuickSolve=$('solveButton').onclick,originalAISolve=$('aiButton').onclick;
function checkedQuestion(){if(photoFlow.available&&photoFlow.confirmed!==$('question').value.trim()){photoStatus('Check the reading and press “This matches my question” first.',true);review.scrollIntoView({behavior:'smooth',block:'center'});return false}return true;}
$('solveButton').onclick=()=>{if(checkedQuestion())originalQuickSolve();};
$('aiButton').onclick=()=>{if(checkedQuestion())originalAISolve();};
$('question').addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='Enter'&&!checkedQuestion()){e.preventDefault();e.stopImmediatePropagation();}},true);
const css=document.createElement('style');css.textContent='#mathPhotoFlow,#mathReviewV2{border:1px solid #63517d;border-radius:16px;padding:15px;margin:15px 0;background:#1b1729}#mathPhotoPreview{display:block;max-width:100%;max-height:260px;object-fit:contain;margin:12px auto;border-radius:10px;background:white}.photo-flow-head{font:10px monospace;letter-spacing:1px;color:#c9b0f0;display:flex;justify-content:space-between}.photo-flow-status{color:#cbb9ee}.photo-flow-error{color:#ffd1d1;background:#482632;padding:12px;border-radius:10px}#mathExpressionPreview{white-space:pre-wrap;overflow-wrap:anywhere;padding:14px 0;font-size:19px}#rawOCRText{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}#confirmMathReading{background:#7254a5;color:white;width:100%}#mathConfirmStatus{font-size:12px;color:#c5b1df}';document.head.append(css);
