'use strict';
// Conservative spatial reconstruction. OCR is not a guaranteed maths recognizer.
const PhotoMath=(()=>{
function reconstruct(lines){
 const rows=lines.filter(l=>l.text&&Number.isFinite(l.top)).sort((a,b)=>a.top-b.top);
 function read(line){
  const parts=(line.elements||[]).slice().sort((a,b)=>a.left-b.left);
  if(parts.length<2)return line.text;
  const heights=parts.map(p=>p.bottom-p.top).sort((a,b)=>b-a);
  const baseHeight=heights[0];
  const bases=parts.filter(p=>p.bottom-p.top>=baseHeight*.7);
  const baseline=Math.max(...bases.map(p=>p.bottom));
  let out='';
  for(const p of parts){
   const raised=p.bottom<baseline-baseHeight*.25&&(p.bottom-p.top)<baseHeight*.8;
   if(raised&&out&&/^[0-9⁰¹²³⁴⁵⁶⁷⁸⁹+−-]+$/.test(p.text))out+='^('+p.text.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]/g,c=>'⁰¹²³⁴⁵⁶⁷⁸⁹'.indexOf(c))+')';
   else out+=p.text;
  }
  return out;
 }
 // Only a clearly separated, horizontally aligned two-row fraction is proposed.
 if(rows.length===2){const a=rows[0],b=rows[1];const ca=(a.left+a.right)/2,cb=(b.left+b.right)/2;
  if(b.top>=a.bottom&&Math.abs(ca-cb)<Math.max(a.right-a.left,b.right-b.left)*.25&&/^[0-9.]+$/.test(b.text.trim())&&!/[=a-z]/i.test(a.text))return {text:'('+read(a)+')/('+read(b)+')',layout:true};
 }
 return {text:rows.map(read).join('\n'),layout:rows.some(l=>read(l)!==l.text)};
}
function readTranscription(answer){
 let text=String(answer||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');
 let data;
 try{data=JSON.parse(text);}catch(e){throw Error('AI did not return a clear maths transcription. Try a tighter crop or use Solve with AI and include the photo.');}
 if(!data||typeof data.expression!=='string'||typeof data.uncertain!=='boolean')throw Error('Photo reading was not in the expected format. Please try again.');
 if(data.uncertain)return {expression:'',note:typeof data.note==='string'?data.note:'Some symbols are unclear.'};
 const expression=data.expression.trim();
 if(!expression||expression.length>600||/[<>`?]/.test(expression))throw Error('Photo reading is incomplete. Crop to one clear question.');
 return {expression,note:''};
}
return {reconstruct,readTranscription};
})();
if(typeof module!=='undefined')module.exports=PhotoMath;
