'use strict';
// No eval, network, or external dependencies. Real-valued arithmetic and degree <=2 polynomials.
const MathMate = (() => {
const EPS=1e-12;
const fmt=n=>Number.isFinite(n)?String(Number(n.toPrecision(12))):'undefined';
function fail(s){throw new Error(s);}
function finite(n){if(!Number.isFinite(n))fail('This calculation has no finite real result.');return n;}
function normalize(text){
 const digits={'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁺':'+','⁻':'-'};
 return String(text).replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+/g,s=>'^('+Array.from(s,c=>digits[c]).join('')+')')
 .replace(/[−–]/g,'-').replace(/[×·]/g,'*').replace(/[÷／]/g,'/').replace(/√\s*\(/g,'sqrt(').replace(/√\s*(\d+(?:\.\d+)?)/g,'sqrt($1)');
}
function parse(text){
 text=normalize(text);
 if(text.includes('°'))fail('Degree symbol ° is ambiguous here. For power zero use ^0 (for example 5^0); for trig use sin(30). Check the photo before solving.');
 const bracketStack=[],closing={')':'(',']':'[','}':'{'};
 for(const ch of text){if('([{'.includes(ch))bracketStack.push(ch);else if(')]}'.includes(ch)&&bracketStack.pop()!==closing[ch])fail('Match each opening bracket with its closing bracket.');}
 if(bracketStack.length)fail('Close every opening bracket.');
 text=text.replace(/[\[{]/g,'(').replace(/[\]}]/g,')').replace(/[−–]/g,'-').replace(/×/g,'*').replace(/÷/g,'/').replace(/π/g,'pi').replace(/²/g,'^2').trim();
 if(!text||text.length>300)fail('Enter a calculation, up to 300 characters.');
 const ts=[];let p=0;
 while(p<text.length){
  if(/\s/.test(text[p])){p++;continue;}
  const rest=text.slice(p),num=rest.match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/),name=rest.match(/^(sin|cos|tan|sqrt|log|ln|abs|pi|x|y|e)/i);
  if(num){ts.push({t:'n',v:finite(Number(num[0]))});p+=num[0].length;}
  else if(name){ts.push({t:name[0].toLowerCase()});p+=name[0].length;}
  else if('+-*/^()%'.includes(text[p]))ts.push({t:text[p++]});
  else fail('Unsupported text. Try 2x + 5 = 15 or sqrt(81).');
 }
 ts.push({t:'end'});let i=0;
 const peek=()=>ts[i].t, take=()=>ts[i++];
 const atomStart=t=>['n','x','y','pi','e','(','sin','cos','tan','sqrt','log','ln','abs'].includes(t);
 function atom(){let t=take();if(t.t==='n')return {k:'n',v:t.v};if(['x','y'].includes(t.t))return {k:t.t};if(['pi','e'].includes(t.t))return{k:'n',v:t.t==='pi'?Math.PI:Math.E};
  if(t.t==='('){let a=add();if(take().t!==')')fail('Close the bracket with ).');return a;}
  if(['sin','cos','tan','sqrt','log','ln','abs'].includes(t.t)){if(take().t!=='(')fail('Use function brackets, for example sqrt(81).');let a=add();if(take().t!==')')fail('Close the function bracket.');return{k:'fn',f:t.t,a};}
  fail('Check the numbers, operators, and brackets.');
 }
 function post(){let a=atom();while(peek()==='%'){take();a={k:'/',a,b:{k:'n',v:100}};}return a;}
 function power(){let a=post();if(peek()==='^'){take();a={k:'^',a,b:unary()};}return a;}
 function unary(){if(peek()==='+'){take();return unary();}if(peek()==='-'){take();return{k:'neg',a:unary()};}return power();}
 function mul(){let a=unary();while(peek()==='*'||peek()==='/'||atomStart(peek())){let op=peek()==='*'||peek()==='/'?take().t:'*';a={k:op,a,b:unary()};}return a;}
 function add(){let a=mul();while(peek()==='+'||peek()==='-'){let op=take().t;a={k:op,a,b:mul()};}return a;}
 const a=add();if(peek()!=='end')fail('Check the expression syntax.');return a;
}
function calc(n,env={}){
 if(n.k==='n')return n.v;
 if(n.k==='x'||n.k==='y'){if(env[n.k]===undefined)fail('Add an equals sign to solve an equation.');return env[n.k];}
 if(n.k==='neg')return finite(-calc(n.a,env));
 if(n.k==='fn'){let a=calc(n.a,env),v;switch(n.f){case 'sqrt':v=Math.sqrt(a);break;case 'abs':v=Math.abs(a);break;case 'ln':v=Math.log(a);break;case 'log':v=Math.log10(a);break;case 'sin':v=Math.sin(a*Math.PI/180);break;case 'cos':v=Math.cos(a*Math.PI/180);break;case 'tan':if(Math.abs(Math.cos(a*Math.PI/180))<EPS)fail('tan is undefined at this angle.');v=Math.tan(a*Math.PI/180);break;}return finite(v);}
 const a=calc(n.a,env),b=calc(n.b,env);if(n.k==='/'&&b===0)fail('Cannot divide by zero.');
 return finite(n.k==='+'?a+b:n.k==='-'?a-b:n.k==='*'?a*b:n.k==='/'?a/b:Math.pow(a,b));
}
const clean=p=>{for(const k of Object.keys(p)){finite(p[k]);if(p[k]===0)delete p[k];}return p;};
function plus(a,b,sign=1){let p={...a};for(const k in b)p[k]=(p[k]||0)+sign*b[k];return clean(p);}
function scale(a,v){const p={};for(const k in a)p[k]=a[k]*v;return clean(p);}
function times(a,b){let p={};for(const k in a)for(const l in b){const [x,y]=k.split(',').map(Number),[u,v]=l.split(',').map(Number);if(x+y+u+v>2)fail('Offline equations support degree 1 or 2 only.');const key=[x+u,y+v].join(',');p[key]=(p[key]||0)+a[k]*b[l];}return clean(p);}
function poly(n){
 if(n.k==='n')return clean({'0,0':n.v});if(n.k==='x')return{'1,0':1};if(n.k==='y')return{'0,1':1};
 if(n.k==='neg')return scale(poly(n.a),-1);
 if(n.k==='fn')return clean({'0,0':calc(n)});
 let a=poly(n.a),b=poly(n.b);
 if(n.k==='+')return plus(a,b);if(n.k==='-')return plus(a,b,-1);if(n.k==='*')return times(a,b);
 if(n.k==='/'){if(Object.keys(b).some(k=>k!=='0,0'))fail('Variable denominators need an online solver.');if(!b['0,0'])fail('Cannot divide by zero.');return scale(a,1/b['0,0']);}
 if(n.k==='^'){if(Object.keys(b).some(k=>k!=='0,0'))fail('Variable exponents need an online solver.');const e=b['0,0']||0;
  if(Object.keys(a).every(k=>k==='0,0'))return clean({'0,0':finite(Math.pow(a['0,0']||0,e))});
  if(!Number.isInteger(e)||e<0||e>2)fail('Offline equations support powers 0, 1 and 2.');return e===0?{'0,0':1}:e===1?a:times(a,a);
 }
}
function equation(s){const sides=s.split('=');if(sides.length!==2||sides.some(v=>!v.trim()))fail('Use one equals sign per equation.');return plus(poly(parse(sides[0])),poly(parse(sides[1])),-1);}
function label(p){let parts=[];for(const k of ['2,0','1,1','0,2','1,0','0,1','0,0']){let c=p[k]||0;if(!c)continue;let v={'2,0':'x²','1,1':'xy','0,2':'y²','1,0':'x','0,1':'y','0,0':''}[k];let mag=(Math.abs(c)===1&&v?'':fmt(Math.abs(c)))+v;parts.push((parts.length?(c<0?' − ':' + '):(c<0?'−':''))+mag);}return parts.join('')||'0';}
function solve(text,ml=false){
 const tr=(en,ma)=>ml?ma:en;
 text=text.trim();if(!text)fail(tr('Enter your maths question.','ചോദ്യം നൽകുക.'));
 if(text.length>600)fail('Please keep the question under 600 characters.');
 const rows=text.split(/[;\n]+/).map(s=>s.trim()).filter(Boolean);
 if(rows.length>2)fail('Use at most two equations in x and y.');
 if(!text.includes('=')){
  if(rows.length!==1)fail('Enter one calculation at a time.');
  const ast=parse(text),value=calc(ast),steps=[];
  function walk(n){if(n.a)walk(n.a);if(n.b)walk(n.b);if(n.k==='fn')steps.push(`${n.f}(${fmt(calc(n.a))}) = ${fmt(calc(n))}`);else if(n.a&&n.b)steps.push(`${fmt(calc(n.a))} ${n.k} ${fmt(calc(n.b))} = ${fmt(calc(n))}`);}
  walk(ast);
  return{answer:fmt(value),values:[value],steps:steps.length?steps:[tr('The number is already simplified.','ഈ സംഖ്യ ഇതിനകം ലളിതമാണ്.')],note:tr('BODMAS: brackets, powers/roots, then ×/÷ left to right, then +/− left to right. Trigonometry uses degrees. Decimals: 12 significant digits.','BODMAS: brackets, powers/roots, ശേഷം ×/÷ ഇടത്തുനിന്ന് വലത്തേക്ക്, ശേഷം +/− ഇടത്തുനിന്ന് വലത്തേക്ക്. Trigonometry ഡിഗ്രിയിൽ. ദശാംശങ്ങൾ: 12 significant digits.')};
 }
 const ps=rows.map(equation);
 if(ps.length===2){
  if(ps.some(p=>Object.keys(p).some(k=>['2,0','1,1','0,2'].includes(k))))fail('For two equations, use linear terms in x and y only.');
  const [p,q]=ps,a=p['1,0']||0,b=p['0,1']||0,c=-(p['0,0']||0),d=q['1,0']||0,e=q['0,1']||0,f=-(q['0,0']||0),det=a*e-b*d;
  if(det===0){const consistent=(a*f-c*d===0&&b*f-c*e===0)&&!((a===0&&b===0&&c!==0)||(d===0&&e===0&&f!==0));return{answer:tr(consistent?'Infinitely many solutions':'No solution',consistent?'അനന്തമായ പരിഹാരങ്ങൾ':'പരിഹാരമില്ല'),values:[],steps:[`${label(p)} = 0`,`${label(q)} = 0`,tr('Compare the coefficients and constants.','ഗുണകങ്ങളും സ്ഥിരസംഖ്യകളും താരതമ്യം ചെയ്യുക.')]};}
  const x=finite((c*e-b*f)/det),y=finite((a*f-c*d)/det);
  return{answer:`x = ${fmt(x)}, y = ${fmt(y)}`,values:[x,y],steps:[`${label(p)} = 0`,`${label(q)} = 0`,`D = (${fmt(a)} × ${fmt(e)}) − (${fmt(b)} × ${fmt(d)}) = ${fmt(det)}`,`x = [(${fmt(c)} × ${fmt(e)}) − (${fmt(b)} × ${fmt(f)})] / ${fmt(det)} = ${fmt(x)}`,`y = [(${fmt(a)} × ${fmt(f)}) − (${fmt(c)} × ${fmt(d)})] / ${fmt(det)} = ${fmt(y)}`,tr('Substitute x and y in the original equations to check.','x, y മൂല്യങ്ങൾ ആദ്യ സമവാക്യങ്ങളിൽ നൽകി പരിശോധിക്കുക.')]};
 }
 const p=ps[0];if(Object.keys(p).some(k=>k.split(',')[1]!=='0'))fail('For one equation, use x only. For x and y, enter two equations on separate lines.');
 const a=p['2,0']||0,b=p['1,0']||0,c=p['0,0']||0,steps=[tr('Bring all terms to the left and combine like terms.','എല്ലാ പദങ്ങളും ഇടത്തേക്ക് മാറ്റി സമാനപദങ്ങൾ കൂട്ടുക.'),`${label(p)} = 0`];
 if(a===0){if(b===0)return{answer:tr(c===0?'All real x are solutions':'No solution',c===0?'എല്ലാ യഥാർത്ഥ x മൂല്യങ്ങളും പരിഹാരമാണ്':'പരിഹാരമില്ല'),values:[],steps};const x=finite(-c/b);return{answer:`x = ${fmt(x)}`,values:[x],steps:[...steps,`${fmt(b)}x = ${fmt(-c)}`,`x = ${fmt(-c)} / ${fmt(b)} = ${fmt(x)}`]};}
 const D=finite(b*b-4*a*c);steps.push(`a = ${fmt(a)}, b = ${fmt(b)}, c = ${fmt(c)}`,`D = b² − 4ac = ${fmt(D)}`);
 if(D<0)return{answer:tr('No real roots','യഥാർത്ഥ മൂലങ്ങളില്ല'),values:[],steps:[...steps,tr('The discriminant is negative. Complex roots are not supported in this version.','Discriminant നെഗറ്റീവ് ആണ്. ഈ പതിപ്പിൽ complex roots ലഭ്യമല്ല.')]};
 const q=-0.5*(b+(b>=0?1:-1)*Math.sqrt(D)),roots=D===0?[-b/(2*a)]:[q/a,c/q];roots.forEach(finite);roots.sort((a,b)=>a-b);
 return{answer:roots.map((x,i)=>`x${roots.length>1?i+1:''} = ${fmt(x)}`).join(', '),values:roots,steps:[...steps,'x = (−b ± √D) / (2a)',...roots.map(x=>`x = ${fmt(x)}`)]};
}
return {solve,parse,calc,fmt,normalize};
})();
if(typeof module!=='undefined')module.exports=MathMate;
