from pathlib import Path
p=Path(__file__).parent/'app/src/main/assets'
s=(p/'ui.template.html').read_text()
s=s.replace('/* STUDIO_CSS */',(p/'studio.css').read_text()).replace('/* STUDIO_JS */',(p/'studio.js').read_text())
s=s.replace('/* NEON_CSS */',(p/'neon.css').read_text().replace('var(--neon-art)', 'url(data:image/png;base64,'+__import__('base64').b64encode((p/'math/neon-art.png').read_bytes()).decode()+')')).replace('/* NEON_JS */',(p/'neon.js').read_text())
for token,name in [('VISION_READ','vision-read.js'),('PHOTO_MATH','photo-math.js'),('MULTIPLICATION','multiplication.js'),('STUDY','study.js'),('STUDY_UI','study-ui.js'),('CHALLENGES','challenges.js'),('CHALLENGE_UI','challenge-ui.js'),('BODMAS_UI','bodmas-ui.js'),('ENGINE','engine.js'),('PRACTICE','practice.js'),('POWERS','powers.js'),('FORMULAS','formula-book.js'),('LESSON_STEPS','lesson-steps.js'),('LEARNING','learning.js'),('ENHANCEMENTS','enhancements.js')]:
    s=s.replace('/* '+token+' */',(p/name).read_text())
(p/'index.html').write_text(s)
