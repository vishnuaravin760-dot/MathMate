from pathlib import Path
p=Path(__file__).parent/'app/src/main/assets'
s=(p/'ui.template.html').read_text()
s=s.replace('/* STUDIO_CSS */',(p/'studio.css').read_text()).replace('/* STUDIO_JS */',(p/'studio.js').read_text())
for token,name in [('VISION_READ','vision-read.js'),('PHOTO_MATH','photo-math.js'),('MULTIPLICATION','multiplication.js'),('STUDY','study.js'),('STUDY_UI','study-ui.js'),('CHALLENGES','challenges.js'),('CHALLENGE_UI','challenge-ui.js'),('BODMAS_UI','bodmas-ui.js'),('ENGINE','engine.js'),('PRACTICE','practice.js'),('POWERS','powers.js'),('FORMULAS','formula-book.js'),('LESSON_STEPS','lesson-steps.js'),('LEARNING','learning.js'),('ENHANCEMENTS','enhancements.js')]:
    s=s.replace('/* '+token+' */',(p/name).read_text())
(p/'index.html').write_text(s)
