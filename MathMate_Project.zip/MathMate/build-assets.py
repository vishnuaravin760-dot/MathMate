from pathlib import Path
p=Path(__file__).parent/'app/src/main/assets'
s=(p/'ui.template.html').read_text()
for token,name in [('ENGINE','engine.js'),('PRACTICE','practice.js'),('POWERS','powers.js'),('FORMULAS','formula-book.js'),('ENHANCEMENTS','enhancements.js')]:
    s=s.replace('/* '+token+' */',(p/name).read_text())
(p/'index.html').write_text(s)
